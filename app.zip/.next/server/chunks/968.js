exports.id = 968;
exports.ids = [968];
exports.modules = {

/***/ 9066:
/***/ ((module) => {

// Exports
module.exports = {
	"background": "style_background__xD1uT",
	"isVisible": "style_isVisible__PGRtb",
	"modal": "style_modal__ARB1G",
	"btnClose": "style_btnClose__GCqi5",
	"withHead": "style_withHead__4__GK"
};


/***/ }),

/***/ 1079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9066);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function Modal({ children , isVisible =false , withHead =false , onClose =()=>{} , className ,  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().background), className, {
            [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().isVisible)]: isVisible
        }),
        onClick: ()=>onClose(),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().modal),
            onClick: (e)=>e.stopPropagation(),
            children: [
                children,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().btnClose), {
                        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().withHead)]: withHead
                    }),
                    onClick: ()=>onClose(),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IconClose, {})
                })
            ]
        })
    });
};
const IconClose = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        stroke: "#747888",
        strokeWidth: "1.75",
        strokeMiterlimit: "10",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M6 18L18 6"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M18 18L6 6"
            })
        ]
    });


/***/ }),

/***/ 6237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const walletProvider = {
    async connect (walletConnector) {
        switch(walletConnector){
            case "martian":
                const { martian  } = window;
                if (martian) {
                    const response = await martian.connect();
                    const isConnected = await martian.isConnected();
                    if (isConnected) {
                        window.localStorage.setItem("walletConnector", "martian");
                        return response.address;
                    }
                } else {
                    window.open("https://www.martianwallet.xyz/", "_blank");
                }
                break;
        }
        return "";
    },
    async isConnected () {
        const walletConnector = window.localStorage.getItem("walletConnector");
        switch(walletConnector){
            case "martian":
                const { martian  } = window;
                if (martian) {
                    await martian.connect();
                    const isConnected = await martian.isConnected();
                    if (isConnected) {
                        return true;
                    }
                }
                break;
        }
        return false;
    },
    async disconnect () {
        const walletConnector = window.localStorage.getItem("walletConnector");
        window.localStorage.removeItem("walletConnector");
        switch(walletConnector){
            case "martian":
                const { martian  } = window;
                if (martian) {
                    await martian.disconnect();
                }
                break;
        }
    },
    async getAccount () {
        const walletConnector = window.localStorage.getItem("walletConnector");
        switch(walletConnector){
            case "martian":
                const { martian  } = window;
                if (martian) {
                    const responseConnect = await martian.connect();
                    const isConnected = await martian.isConnected();
                    if (isConnected) {
                        return responseConnect.address;
                    }
                }
                break;
        }
        return "";
    },
    async sendTransaction (params) {
        const walletConnector = window.localStorage.getItem("walletConnector");
        switch(walletConnector){
            case "martian":
                const { martian  } = window;
                if (martian) {
                    const responseConnect = await martian.connect();
                    const isConnected = await martian.isConnected();
                    if (isConnected) {
                        const sender = responseConnect.address;
                        const transaction = await martian.generateTransaction(sender, params === null || params === void 0 ? void 0 : params.transactionData);
                        return await martian.signAndSubmitTransaction(transaction);
                    }
                }
                break;
        }
        return false;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (walletProvider);


/***/ }),

/***/ 9688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3290);
/* harmony import */ var nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0__);

const users = [
    {
        user: "dm",
        password: "dmxyz"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0___default()({
    users: users
}));


/***/ })

};
;