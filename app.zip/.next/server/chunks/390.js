"use strict";
exports.id = 390;
exports.ids = [390];
exports.modules = {

/***/ 4390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SeoMeta)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./logic/constants/seo.js
const DMSEO = {
    title: "DeltaMoney",
    og: "/og-image.png",
    favicon: "/favicon.png",
    url: "https://deltamoney.xyz/",
    pages: {
        home: {
            title: "DeltaMoney",
            description: "DeltaMoney offers leveraged yield farming positions that allow users to grow their principles and earn more profits.",
            keywords: ""
        },
        app: {
            title: "DeltaMoney",
            description: "DeltaMoney offers leveraged yield farming positions that allow users to grow their principles and earn more profits.",
            keywords: ""
        },
        borrow: {
            title: "DeltaMoney Borrow",
            description: "DeltaMoney offers leveraged yield farming positions that allow users to grow their principles and earn more profits.",
            keywords: ""
        },
        faucet: {
            title: "DeltaMoney Faucet",
            description: "DeltaMoney offers leveraged yield farming positions that allow users to grow their principles and earn more profits.",
            keywords: ""
        }
    }
};

;// CONCATENATED MODULE: ./components/common/SeoMeta/index.jsx



function SeoMeta({ type , title , description , og , url , noindex , keywords ,  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                charSet: "UTF-8"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "viewport",
                content: "initial-scale=1.0, width=device-width"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                httpEquiv: "X-UA-Compatible",
                content: "ie=edge"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "format-detection",
                content: "telephone=no"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "theme-color",
                content: "#420FD3"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:type",
                content: "website"
            }),
            DMSEO.pages.hasOwnProperty(type) ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: DMSEO.pages[type].title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: DMSEO.pages[type].title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:title",
                        content: DMSEO.pages[type].title
                    }),
                    DMSEO.pages[type].hasOwnProperty("description") && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:description",
                                content: DMSEO.pages[type].description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "twitter:description",
                                content: DMSEO.pages[type].description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "description",
                                content: DMSEO.pages[type].description
                            })
                        ]
                    }),
                    DMSEO.pages[type].hasOwnProperty("keywords") && DMSEO.pages[type].keywords !== "" && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "keywords",
                            content: DMSEO.pages[type].keywords
                        })
                    }),
                    DMSEO.pages[type].hasOwnProperty("og") ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:image",
                                content: DMSEO.url + DMSEO.pages[type].og
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:image:secure_url",
                                content: DMSEO.url + DMSEO.pages[type].og
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "twitter:image",
                                content: DMSEO.url + DMSEO.pages[type].og
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:image",
                                content: DMSEO.url + DMSEO.og
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:image:secure_url",
                                content: DMSEO.url + DMSEO.og
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "twitter:image",
                                content: DMSEO.url + DMSEO.og
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title ? title + " | " + DMSEO.title : DMSEO.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: title ? title + " | " + DMSEO.title : DMSEO.title
                    }),
                    description && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                property: "og:description",
                                content: description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "twitter:description",
                                content: description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "description",
                                content: description
                            })
                        ]
                    }),
                    keywords && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                            name: "keywords",
                            content: keywords
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image",
                        content: og ? og : DMSEO.url + DMSEO.og
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image:secure_url",
                        content: og ? og : DMSEO.url + DMSEO.og
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:title",
                        content: title ? title + " | " + DMSEO.title : DMSEO.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:image",
                        content: og ? og : DMSEO.url + DMSEO.og
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:url",
                content: url ? url : "https://deltamoney.xyz/"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:site_name",
                content: DMSEO.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:width",
                content: "1200"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                property: "og:image:height",
                content: "630"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "twitter:site",
                content: "@wearedeltamoney"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "icon",
                href: DMSEO.url + DMSEO.favicon
            }),
            noindex ? /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "robots",
                content: "noindex, nofollow"
            }) : /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                name: "robots",
                content: "follow, index, max-snippet:-1, max-video-preview:-1, max-image-preview:large"
            })
        ]
    });
};


/***/ })

};
;