exports.id = 755;
exports.ids = [755];
exports.modules = {

/***/ 274:
/***/ ((module) => {

// Exports
module.exports = {
	"btn": "style_btn__Su2rY",
	"red": "style_red__P2Bcs",
	"xs": "style_xs__t7lub",
	"sm": "style_sm__w8SY_",
	"md": "style_md___FkdK",
	"lg": "style_lg__WM8Ob",
	"isDisabled": "style_isDisabled__rh7mW",
	"secondary": "style_secondary__fN9gf"
};


/***/ }),

/***/ 7755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(274);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_3__);




function Button({ children , href ="" , target ="" , type ="button" , secondary =false , disabled =false , red =false , loading =false , size ="md" , className , onClick ,  }) {
    // Sizes: xs, sm, md, lg
    const classes = classnames__WEBPACK_IMPORTED_MODULE_2___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().btn), className, {
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().xs)]: size === "xs",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().sm)]: size === "sm",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().md)]: size === "md",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().lg)]: size === "lg",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().isDisabled)]: disabled,
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().secondary)]: secondary,
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_3___default().red)]: red
    });
    if (href) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: href,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                target: target,
                className: classes,
                children: children
            })
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            type: type,
            disabled: disabled,
            className: classes,
            onClick: onClick,
            children: children
        });
    }
};


/***/ })

};
;