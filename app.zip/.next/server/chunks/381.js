"use strict";
exports.id = 381;
exports.ids = [381];
exports.modules = {

/***/ 1579:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AptosWalletProvider),
/* harmony export */   "q": () => (/* binding */ AptosWalletContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var aptos__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7574);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([aptos__WEBPACK_IMPORTED_MODULE_1__]);
aptos__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const hexStringV0ToV1 = (v0)=>{
    if (typeof v0 === "string") {
        return new aptos__WEBPACK_IMPORTED_MODULE_1__.HexString(v0);
    } else if (v0.hexString) {
        return new aptos__WEBPACK_IMPORTED_MODULE_1__.HexString(v0.toString());
    } else {
        throw new Error(`Invalid hex string object: ${v0}`);
    }
};
const AptosWalletContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)({});
const AptosWalletProvider = ({ children  })=>{
    const { connected , account  } = (0,_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__.useWallet)();
    const { 0: activeWallet , 1: setActiveWallet  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(undefined);
    const { 0: open , 1: setOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (connected && (account === null || account === void 0 ? void 0 : account.address)) {
            setActiveWallet(hexStringV0ToV1(account === null || account === void 0 ? void 0 : account.address));
        } else {
            setActiveWallet(undefined);
        }
    }, [
        connected,
        account
    ]);
    const openModal = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>setOpen(true), []);
    const closeModal = (0,react__WEBPACK_IMPORTED_MODULE_3__.useCallback)(()=>setOpen(false), []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AptosWalletContext.Provider, {
        value: {
            activeWallet,
            open,
            openModal,
            closeModal
        },
        children: children
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1381:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1579);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_1__]);
contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const useAptosWallet = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_1__/* .AptosWalletContext */ .q);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAptosWallet);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;