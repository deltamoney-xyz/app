exports.id = 527;
exports.ids = [527];
exports.modules = {

/***/ 4867:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "style_title__TGzn0",
	"h1": "style_h1__uP0FK",
	"h2": "style_h2__G0lM_",
	"h3": "style_h3__G5hBw",
	"h4": "style_h4__Mdmo2",
	"h5": "style_h5__tUbyA",
	"h6": "style_h6__sv3x1",
	"tac": "style_tac__42tIq"
};


/***/ }),

/***/ 527:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Title)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4867);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function Title({ children , size , type , block =false , tac =false , className , ...props }) {
    const classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().title), className, {
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h1)]: size === "h1",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h2)]: size === "h2",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h3)]: size === "h3",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h4)]: size === "h4",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h5)]: size === "h5",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().h6)]: size === "h6",
        [(_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().tac)]: tac
    });
    if (block) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: classes,
            ...props,
            children: children
        });
    } else {
        if (type === "h1") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: classes,
                ...props,
                children: children
            });
        } else if (type === "h2") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: classes,
                ...props,
                children: children
            });
        } else if (type === "h3") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: classes,
                ...props,
                children: children
            });
        } else if (type === "h4") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                className: classes,
                ...props,
                children: children
            });
        } else if (type === "h5") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                className: classes,
                ...props,
                children: children
            });
        } else if (type === "h6") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                className: classes,
                ...props,
                children: children
            });
        }
    }
};


/***/ })

};
;