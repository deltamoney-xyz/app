(() => {
var exports = {};
exports.id = 738;
exports.ids = [738];
exports.modules = {

/***/ 5183:
/***/ ((module) => {

// Exports
module.exports = {
	"head": "app_head__nEcTJ",
	"balance": "app_balance__M2M4A",
	"balanceValue": "app_balanceValue__uPV_2",
	"balanceTitle": "app_balanceTitle__yZbMz",
	"balanceCaption": "app_balanceCaption__xyZkh",
	"progress": "app_progress__4F8OE",
	"progressHead": "app_progressHead__HhSPN",
	"progressFoot": "app_progressFoot__Sh0px",
	"progressBar": "app_progressBar__xmOTK",
	"grid": "app_grid__SHvm1",
	"table": "app_table__ZuDOi",
	"tableTitle": "app_tableTitle__9qCfK",
	"modalHead": "app_modalHead__d6faX",
	"modalList": "app_modalList__zCCe1",
	"modalTabs": "app_modalTabs__CT4BE",
	"isSelected": "app_isSelected__9hwck",
	"form": "app_form__OMK3R",
	"btnSubmit": "app_btnSubmit__vIUH3",
	"btnMax": "app_btnMax__HGFez",
	"field": "app_field__eKK9_"
};


/***/ }),

/***/ 9688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3290);
/* harmony import */ var nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0__);

const users = [
    {
        user: "dm",
        password: "dmxyz"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (nextjs_basic_auth__WEBPACK_IMPORTED_MODULE_0___default()({
    users: users
}));


/***/ }),

/***/ 6581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PageFaucet),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9688);
/* harmony import */ var components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4390);
/* harmony import */ var styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5183);
/* harmony import */ var styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3__);




function PageFaucet() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                type: "faucet"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "wrap-fluid",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3___default().head),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3___default().balance),
                        "data-color": "blue",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_3___default().balanceTitle),
                            children: "Coming soon..."
                        })
                    })
                })
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { req , res  } = ctx;
    // await httpAuthCheck(req, res);
    if (ctx.req) {
        await (0,logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(req, res);
    }
    return {
        props: {
            app: true
        }
    };
}


/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 3290:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-basic-auth");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [390], () => (__webpack_exec__(6581)));
module.exports = __webpack_exports__;

})();