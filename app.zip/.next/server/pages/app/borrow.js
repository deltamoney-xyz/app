(() => {
var exports = {};
exports.id = 924;
exports.ids = [924];
exports.modules = {

/***/ 5183:
/***/ ((module) => {

// Exports
module.exports = {
	"head": "app_head__nEcTJ",
	"balance": "app_balance__M2M4A",
	"balanceValue": "app_balanceValue__uPV_2",
	"balanceTitle": "app_balanceTitle__yZbMz",
	"balanceCaption": "app_balanceCaption__xyZkh",
	"progress": "app_progress__4F8OE",
	"progressHead": "app_progressHead__HhSPN",
	"progressFoot": "app_progressFoot__Sh0px",
	"progressBar": "app_progressBar__xmOTK",
	"grid": "app_grid__SHvm1",
	"table": "app_table__ZuDOi",
	"tableTitle": "app_tableTitle__9qCfK",
	"modalHead": "app_modalHead__d6faX",
	"modalList": "app_modalList__zCCe1",
	"modalTabs": "app_modalTabs__CT4BE",
	"isSelected": "app_isSelected__9hwck",
	"form": "app_form__OMK3R",
	"btnSubmit": "app_btnSubmit__vIUH3",
	"btnMax": "app_btnMax__HGFez",
	"field": "app_field__eKK9_"
};


/***/ }),

/***/ 8317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PageApp),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_common_Modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1079);
/* harmony import */ var components_common_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7755);
/* harmony import */ var logic_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2582);
/* harmony import */ var logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9688);
/* harmony import */ var lib_walletProvider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6237);
/* harmony import */ var styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5183);
/* harmony import */ var styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4390);











function PageApp() {
    const { 0: balanceSupply , 1: setBalanceSupply  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(45);
    const { 0: balanceBorrow , 1: setBalanceBorrow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(19);
    const { 0: balanceUser , 1: setBalanceUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: visibleSupplyModal , 1: setVisibleSupplyModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: visibleBorrowModal , 1: setVisibleBorrowModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: selectedCoin , 1: setSelectedCoin  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: modalTab , 1: setModalTab  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const marketsSupply = [
        {
            slug: "aptos",
            label: "Aptos Coin",
            apy: 12,
            wallet: 0
        },
        {
            slug: "btc",
            label: "Bitcoin",
            apy: 12,
            wallet: 0
        },
        {
            slug: "usdc",
            label: "USD Coin",
            apy: 12,
            wallet: 0
        }, 
    ];
    const marketsBorrow = [
        {
            slug: "aptos",
            label: "Aptos Coin",
            apy: 16,
            liquidity: 198873
        },
        {
            slug: "btc",
            label: "Bitcoin",
            apy: 16,
            liquidity: 535893
        },
        {
            slug: "usdc",
            label: "USD Coin",
            apy: 16,
            liquidity: 1087
        }, 
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (balanceUser) {
            setBalanceUser(balanceUser);
        } else {
            const walletConnector = window.localStorage.getItem("walletConnector");
            switch(walletConnector){
                case "martian":
                    if (window.martian && window.martian.legacy) {
                        window.martian.legacy.getAccountBalance((resp)=>{
                            if (resp.status === 200) {
                                setBalanceUser(resp.data);
                                console.log("Current balance of the selected account:", resp.data);
                            // 5000
                            } else {
                                console.log(resp.message);
                            // Something went wrong within Martian wallet.
                            }
                        });
                    }
                    break;
            }
        }
    }, [
        balanceUser
    ]);
    // const NODE_URL = 'https://fullnode.devnet.aptoslabs.com'
    // const FAUCET_URL = 'https://faucet.devnet.aptoslabs.com'
    // const aptosClient = new AptosClient(NODE_URL)
    // const aptosFaucetClient = new FaucetClient(NODE_URL, FAUCET_URL)
    const onOpenModal = (item)=>{
        switch(item.type){
            case "supply":
                setVisibleSupplyModal(true);
                break;
            case "borrow":
                setVisibleBorrowModal(true);
                break;
            default:
                console.error("Choose right coin!");
        }
        setSelectedCoin(item.data);
    };
    const onCloseModal = ()=>{
        setVisibleSupplyModal(false);
        setVisibleBorrowModal(false);
        setModalTab(0);
        setTimeout(()=>setSelectedCoin({}), 300);
    };
    const onDeposit = async (values)=>{
        console.log(values);
        // const address = await walletProvider.getAccount()
        const contractAddr = "0x81695cd677d9aae07ceffd7af1003f1be2af8cc7b12d433d50854376a61a90e1";
        // stake
        // const methoCall = 'stake'
        const methoCall = "unstake";
        const res = await lib_walletProvider__WEBPACK_IMPORTED_MODULE_7__/* ["default"].sendTransaction */ .Z.sendTransaction({
            transactionData: {
                type: "entry_function_payload",
                function: `${contractAddr}::StakingWood::${methoCall}`,
                arguments: [
                    contractAddr,
                    parseInt(values.value)
                ],
                type_arguments: []
            }
        });
        console.log(res);
    };
    const onWithdraw = async (values)=>{
        console.log(values);
    };
    const onBorrow = async (values)=>{
        console.log(values);
    };
    const onRepay = async (values)=>{
        console.log(values);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                type: "borrow"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrap-fluid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().head),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balance),
                                "data-color": "green",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceTitle),
                                        children: "Supply balance"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceCaption),
                                        children: "Updated 1 minute ago"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceValue),
                                        children: [
                                            "$",
                                            (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(balanceSupply)
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balance),
                                "data-color": "blue",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceTitle),
                                        children: "Borrow balance"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceCaption),
                                        children: "Updated 30 seconds ago"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().balanceValue),
                                        children: [
                                            "$",
                                            (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(balanceBorrow)
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().progress),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().progressHead),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Borrow limit"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().progressBar),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    style: {
                                        width: "18%"
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().progressFoot),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "1.8%"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            "$",
                                            (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(balanceBorrow)
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().grid),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().table),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tableTitle),
                                        children: "Supply markets"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "Asset"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "APY"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "Wallet"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                children: marketsSupply.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                onClick: ()=>onOpenModal({
                                                                        type: "supply",
                                                                        data: item
                                                                    }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    src: `/static/img/svg/coins/${item.slug.toLowerCase()}.svg`,
                                                                                    alt: "",
                                                                                    width: 40,
                                                                                    height: 40,
                                                                                    loading: "lazy"
                                                                                }),
                                                                                item.label
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            children: [
                                                                                item.apy,
                                                                                "%"
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    item.wallet,
                                                                                    " ",
                                                                                    item.slug.toUpperCase()
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {})
                                                                        ]
                                                                    })
                                                                ]
                                                            }, item.slug),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    style: {
                                                                        height: 8
                                                                    },
                                                                    colSpan: 3
                                                                })
                                                            })
                                                        ]
                                                    }))
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().table),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().tableTitle),
                                        children: "Borrow markets"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "Asset"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "APY"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            children: "Liquidity"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                children: marketsBorrow.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                onClick: ()=>onOpenModal({
                                                                        type: "borrow",
                                                                        data: item
                                                                    }),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    src: `/static/img/svg/coins/${item.slug.toLowerCase()}.svg`,
                                                                                    alt: "",
                                                                                    width: 40,
                                                                                    height: 40,
                                                                                    loading: "lazy"
                                                                                }),
                                                                                item.label
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                            children: [
                                                                                item.apy,
                                                                                "%"
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                        children: [
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(item.liquidity),
                                                                                    " ",
                                                                                    item.slug.toUpperCase()
                                                                                ]
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {})
                                                                        ]
                                                                    })
                                                                ]
                                                            }, item.slug),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    style: {
                                                                        height: 8
                                                                    },
                                                                    colSpan: 3
                                                                })
                                                            })
                                                        ]
                                                    }))
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Modal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                isVisible: visibleSupplyModal,
                onClose: ()=>onCloseModal(),
                children: Object.keys(selectedCoin).length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalHead),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `/static/img/svg/coins/${selectedCoin.slug.toLowerCase()}.svg`,
                                    alt: "",
                                    width: 56,
                                    height: 56,
                                    loading: "lazy"
                                }),
                                selectedCoin.label
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalList),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: `/static/img/svg/coins/${selectedCoin.slug.toLowerCase()}.svg`,
                                            alt: "",
                                            width: 40,
                                            height: 40,
                                            loading: "lazy"
                                        }),
                                        selectedCoin.label,
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                selectedCoin.slug === "aptos" ? (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(balanceUser) : (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(selectedCoin.wallet),
                                                " ",
                                                selectedCoin.slug.toUpperCase()
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/static/img/svg/icons/rate.svg",
                                            alt: "",
                                            width: 40,
                                            height: 40,
                                            loading: "lazy"
                                        }),
                                        "Supply Rate",
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                selectedCoin.apy,
                                                "%"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalTabs),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: modalTab === 0 ? (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().isSelected) : undefined,
                                                onClick: ()=>setModalTab(0),
                                                children: "Deposit"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: modalTab === 1 ? (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().isSelected) : undefined,
                                                onClick: ()=>setModalTab(1),
                                                children: "Withdraw"
                                            })
                                        })
                                    ]
                                }),
                                modalTab === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
                                        value: yup__WEBPACK_IMPORTED_MODULE_3__.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onDeposit(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                            autoComplete: "off",
                                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().form),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().field),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnMax),
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", 100);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        type: "submit",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnSubmit),
                                                        children: "Deposit"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                }),
                                modalTab === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
                                        value: yup__WEBPACK_IMPORTED_MODULE_3__.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onWithdraw(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                            autoComplete: "off",
                                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().form),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().field),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnMax),
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", 100);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        type: "submit",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnSubmit),
                                                        children: "Withdraw"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Modal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                isVisible: visibleBorrowModal,
                onClose: ()=>onCloseModal(),
                children: Object.keys(selectedCoin).length > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalHead),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `/static/img/svg/coins/${selectedCoin.slug.toLowerCase()}.svg`,
                                    alt: "",
                                    width: 56,
                                    height: 56,
                                    loading: "lazy"
                                }),
                                selectedCoin.label
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalList),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: `/static/img/svg/coins/${selectedCoin.slug.toLowerCase()}.svg`,
                                            alt: "",
                                            width: 40,
                                            height: 40,
                                            loading: "lazy"
                                        }),
                                        selectedCoin.label,
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                (0,logic_helpers__WEBPACK_IMPORTED_MODULE_10__/* .numberFormat */ .Y4)(selectedCoin.liquidity),
                                                " ",
                                                selectedCoin.slug.toUpperCase()
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/static/img/svg/icons/rate.svg",
                                            alt: "",
                                            width: 40,
                                            height: 40,
                                            loading: "lazy"
                                        }),
                                        "Borrow Rate",
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                selectedCoin.apy,
                                                "%"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().modalTabs),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: modalTab === 0 ? (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().isSelected) : undefined,
                                                onClick: ()=>setModalTab(0),
                                                children: "Borrow"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                className: modalTab === 1 ? (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().isSelected) : undefined,
                                                onClick: ()=>setModalTab(1),
                                                children: "Repay"
                                            })
                                        })
                                    ]
                                }),
                                modalTab === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
                                        value: yup__WEBPACK_IMPORTED_MODULE_3__.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onBorrow(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                            autoComplete: "off",
                                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().form),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().field),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnMax),
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", 100);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        type: "submit",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnSubmit),
                                                        children: "Borrow"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                }),
                                modalTab === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
                                        value: yup__WEBPACK_IMPORTED_MODULE_3__.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onRepay(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                            autoComplete: "off",
                                            className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().form),
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().field),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnMax),
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", 100);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        type: "submit",
                                                        className: (styles_pages_app_module_scss__WEBPACK_IMPORTED_MODULE_9___default().btnSubmit),
                                                        children: "Repay"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { req , res  } = ctx;
    if (ctx.req) {
        await (0,logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(req, res);
    }
    return {
        props: {
            app: true
        }
    };
}


/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 3290:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-basic-auth");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,390,755,582,968], () => (__webpack_exec__(8317)));
module.exports = __webpack_exports__;

})();