(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 5166:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "style_section__2wxg3",
	"block": "style_block__c_H69",
	"content": "style_content__SjKfU",
	"grid": "style_grid__N_EFE",
	"item": "style_item__DSP29",
	"media": "style_media__6Mkmb"
};


/***/ }),

/***/ 9955:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "style_section__DWr9O"
};


/***/ }),

/***/ 7942:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "style_section__q3JZP",
	"grid": "style_grid__C1Lql",
	"block": "style_block__DlZH_",
	"title": "style_title__qLIsi",
	"description": "style_description__int7H"
};


/***/ }),

/***/ 6687:
/***/ ((module) => {

// Exports
module.exports = {
	"hero": "home_hero__HJkSU",
	"description": "home_description__V3WjU",
	"buttons": "home_buttons__LB21E",
	"screenshot": "home_screenshot__YO2Ih"
};


/***/ }),

/***/ 3337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/common/Title/index.jsx
var common_Title = __webpack_require__(527);
// EXTERNAL MODULE: ./components/common/Button/index.jsx
var common_Button = __webpack_require__(7755);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
;// CONCATENATED MODULE: ./components/common/InternalLink/index.jsx



function InternalLink({ children , href ="" , target =false , className  }) {
    return /*#__PURE__*/ _jsx("a", {
        href: href,
        target: target,
        className: classnames(styles.link, className),
        children: children
    });
};

// EXTERNAL MODULE: ./components/common/SeoMeta/index.jsx + 1 modules
var SeoMeta = __webpack_require__(4390);
// EXTERNAL MODULE: ./components/pages/home/SectionWhy/style.module.scss
var style_module = __webpack_require__(7942);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./components/pages/home/SectionWhy/index.jsx



function SectionWhy() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (style_module_default()).section,
        id: "section-why",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "wrap",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(common_Title/* default */.Z, {
                    type: "h3",
                    size: "h2",
                    tac: true,
                    children: [
                        "Why ",
                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                        "Delta Money?"
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (style_module_default()).grid,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (style_module_default()).block,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: (style_module_default()).title,
                                    children: "Earn Yield On Multiple Tokens"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (style_module_default()).description,
                                    children: "Delta helps users generate sustainable yields on upcoming Aptos tokens."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/static/img/pages/home/why-1.svg",
                                    alt: "",
                                    loading: "lazy"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (style_module_default()).block,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: (style_module_default()).title,
                                    children: "Vaults and Structured Products"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (style_module_default()).description,
                                    children: "Simple and easy to use vaults."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/static/img/pages/home/why-2.svg",
                                    alt: "",
                                    loading: "lazy"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (style_module_default()).block,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: (style_module_default()).title,
                                    children: "Community Driven"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: (style_module_default()).description,
                                    children: "Become a strategist and earn with us."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/static/img/pages/home/why-3.svg",
                                    alt: "",
                                    loading: "lazy"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./components/pages/home/SectionEarn/style.module.scss
var SectionEarn_style_module = __webpack_require__(5166);
var SectionEarn_style_module_default = /*#__PURE__*/__webpack_require__.n(SectionEarn_style_module);
;// CONCATENATED MODULE: ./components/pages/home/SectionEarn/index.jsx



function SectionEarn() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (SectionEarn_style_module_default()).section,
        id: "section-earn",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "wrap",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (SectionEarn_style_module_default()).block,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (SectionEarn_style_module_default()).content,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(common_Title/* default */.Z, {
                                type: "h3",
                                size: "h2",
                                children: [
                                    "Earn ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    "Extra Yield"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (SectionEarn_style_module_default()).grid,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (SectionEarn_style_module_default()).item,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/static/img/pages/home/earn-1.svg",
                                                alt: "",
                                                width: 64,
                                                height: 64,
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Automatically compound your capital"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (SectionEarn_style_module_default()).item,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/static/img/pages/home/earn-2.svg",
                                                alt: "",
                                                width: 64,
                                                height: 64,
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Better capital efficiency with Delta"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (SectionEarn_style_module_default()).item,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/static/img/pages/home/earn-3.svg",
                                                alt: "",
                                                width: 64,
                                                height: 64,
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Delta Rewards"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (SectionEarn_style_module_default()).item,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/static/img/pages/home/earn-4.svg",
                                                alt: "",
                                                width: 64,
                                                height: 64,
                                                loading: "lazy"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: "Low Gas Fees"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (SectionEarn_style_module_default()).media,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/static/img/pages/home/earn-chart.svg",
                            alt: "",
                            width: 718,
                            height: 680,
                            loading: "lazy"
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./components/pages/home/SectionEcosystem/style.module.scss
var SectionEcosystem_style_module = __webpack_require__(9955);
var SectionEcosystem_style_module_default = /*#__PURE__*/__webpack_require__.n(SectionEcosystem_style_module);
;// CONCATENATED MODULE: ./components/pages/home/SectionEcosystem/index.jsx



function SectionEcosystem() {
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: (SectionEcosystem_style_module_default()).section,
        id: "section-ecosystem",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "wrap",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(common_Title/* default */.Z, {
                    type: "h3",
                    size: "h2",
                    tac: true,
                    children: "Aptos Ecosystem"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/static/img/pages/home/ecosystem.png",
                    alt: "",
                    width: 1248,
                    height: 555,
                    loading: "lazy"
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/pages/home/SectionNews/index.jsx




function SectionNews() {
    const articles = [
        {
            img: "/static/img/del/article-1.png",
            category: "Announcement",
            date: {
                readable: "August 18, 2022",
                machine: "2022-08-18 19:00"
            },
            title: "UNI Drops on Report That SEC is Investigating Uniswap Labs",
            link: "/",
            description: "UNI took a dive following the reports that the US Securities and Exchange Commission (SEC) is ..."
        }, 
    ];
    return /*#__PURE__*/ _jsx("section", {
        className: styles.section,
        id: "section-news",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "wrap",
            children: [
                /*#__PURE__*/ _jsx(Title, {
                    type: "h3",
                    size: "h2",
                    tac: true,
                    children: "News"
                }),
                /*#__PURE__*/ _jsx("p", {
                    className: styles.description,
                    children: "Follow the news with Delta Money"
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: styles.loop,
                    children: [
                        articles && articles.length > 0 && articles.map((item, idx)=>/*#__PURE__*/ _jsx(Article, {
                                data: item
                            }, idx)),
                        /*#__PURE__*/ _jsx(SoonBlock, {}),
                        /*#__PURE__*/ _jsx(MoreBlock, {})
                    ]
                })
            ]
        })
    });
};
const Article = ({ data  })=>/*#__PURE__*/ _jsxs("article", {
        className: styles.article,
        children: [
            /*#__PURE__*/ _jsx("img", {
                src: data.img,
                alt: "",
                width: 400,
                height: 256,
                loading: "lazy",
                className: styles.thumbnail
            }),
            /*#__PURE__*/ _jsxs("ul", {
                className: styles.meta,
                children: [
                    /*#__PURE__*/ _jsx("li", {
                        children: data.category
                    }),
                    /*#__PURE__*/ _jsx("li", {
                        children: /*#__PURE__*/ _jsx("time", {
                            dateTime: data.date.machine,
                            children: data.date.readable
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("h4", {
                className: styles.title,
                children: /*#__PURE__*/ _jsx("a", {
                    href: data.link,
                    target: "_blank",
                    rel: "noreferrer",
                    children: data.title
                })
            }),
            /*#__PURE__*/ _jsx("p", {
                className: styles.description,
                children: data.description
            })
        ]
    });
const SoonBlock = ()=>/*#__PURE__*/ _jsxs("div", {
        className: styles.soonBlock,
        children: [
            /*#__PURE__*/ _jsx("span", {
                children: "Coming Soon"
            }),
            /*#__PURE__*/ _jsx("img", {
                src: "/static/img/pages/home/news-soon.png",
                alt: "",
                width: 400,
                height: 448,
                loading: "lazy"
            })
        ]
    });
const MoreBlock = ()=>/*#__PURE__*/ _jsx("div", {
        className: styles.moreBlock,
        children: /*#__PURE__*/ _jsx(Button, {
            href: "/",
            target: true,
            size: "lg",
            children: "View all Articles"
        })
    });

// EXTERNAL MODULE: ./styles/pages/home.module.scss
var home_module = __webpack_require__(6687);
var home_module_default = /*#__PURE__*/__webpack_require__.n(home_module);
;// CONCATENATED MODULE: ./pages/index.jsx










function Home({ data  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(SeoMeta/* default */.Z, {
                type: "home"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (home_module_default()).hero,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(common_Title/* default */.Z, {
                            size: "h1",
                            type: "h1",
                            tac: true,
                            dangerouslySetInnerHTML: {
                                __html: data.title
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: (home_module_default()).buttons,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(common_Button/* default */.Z, {
                                        size: "md",
                                        disabled: true,
                                        children: "Launch app"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Coming Soon"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (home_module_default()).screenshot,
                            id: "section-overview",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/static/img/pages/home/screenshot.png",
                                alt: "",
                                width: 1036,
                                height: 736,
                                loading: "lazy"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionWhy, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionEarn, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionEcosystem, {})
        ]
    });
};
async function getServerSideProps() {
    const data = {
        title: "Aptos Yield on <br/>Autopilot",
        description: "The placeholder text, beginning with the line lorem"
    };
    return {
        props: {
            data: data
        }
    };
}


/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,390,755,527], () => (__webpack_exec__(3337)));
module.exports = __webpack_exports__;

})();