(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8973:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "style_header__H_da1",
	"wrap": "style_wrap__KPtsu",
	"logo": "style_logo___yUN3",
	"btnConnect": "style_btnConnect__hQt_9",
	"buttons": "style_buttons__jmrrq",
	"info": "style_info__fccoz"
};


/***/ }),

/***/ 5795:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "style_header__PaZYz",
	"logo": "style_logo__ShqOV",
	"menu": "style_menu__Bmrzq",
	"isActive": "style_isActive__F6WP3"
};


/***/ }),

/***/ 6398:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "style_footer__zGrKn",
	"heading": "style_heading__H9_dJ",
	"socials": "style_socials__lVmXR",
	"wrap": "style_wrap__WuVy6",
	"top": "style_top__de0ZA",
	"copyright": "style_copyright__PRtPZ"
};


/***/ }),

/***/ 8122:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "style_menu__beecD",
	"opened": "style_opened__EiA4g",
	"list": "style_list__WHZC7",
	"dropdown": "style_dropdown__eBsST",
	"active": "style_active__ARh_l",
	"label": "style_label__kmrLe"
};


/***/ }),

/***/ 7006:
/***/ ((module) => {

// Exports
module.exports = {
	"advert": "style_advert__zARsS",
	"header": "style_header__XrJEk",
	"wrap": "style_wrap__N4cyT",
	"logo": "style_logo__KYuIe",
	"button": "style_button__j32vH",
	"controls": "style_controls__39x2t",
	"toggleMenu": "style_toggleMenu__Oe25q",
	"isPressed": "style_isPressed__x6jXa"
};


/***/ }),

/***/ 4623:
/***/ ((module) => {

// Exports
module.exports = {
	"parent": "style_parent__HY1c8",
	"main": "style_main__D_619"
};


/***/ }),

/***/ 5384:
/***/ ((module) => {

// Exports
module.exports = {
	"modal": "style_modal__dHBTj",
	"btnConnect": "style_btnConnect__SKA3r",
	"title": "style_title__fs6cH",
	"description": "style_description__lxQOq",
	"list": "style_list__faUFF"
};


/***/ }),

/***/ 5786:
/***/ ((module) => {

// Exports
module.exports = {
	"modal": "style_modal__bZbKD",
	"btnConnect": "style_btnConnect__DVXog",
	"title": "style_title__kRXSB",
	"description": "style_description__vq1zX",
	"subtitle": "style_subtitle__JhMSu",
	"text": "style_text__fPB0O",
	"list": "style_list__dxz6k"
};


/***/ }),

/***/ 204:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AppHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var aptos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7574);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _tippyjs_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4787);
/* harmony import */ var _tippyjs_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_tippyjs_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_common_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7755);
/* harmony import */ var components_common_ConnectModal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6613);
/* harmony import */ var components_common_ProfileModal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3413);
/* harmony import */ var hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1381);
/* harmony import */ var logic_helpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2582);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8973);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([aptos__WEBPACK_IMPORTED_MODULE_2__, components_common_ProfileModal__WEBPACK_IMPORTED_MODULE_9__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_10__]);
([aptos__WEBPACK_IMPORTED_MODULE_2__, components_common_ProfileModal__WEBPACK_IMPORTED_MODULE_9__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function AppHeader() {
    const { wallets  } = (0,_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__.useWallet)();
    const { activeWallet , closeModal  } = (0,hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const { 0: connectedWallet , 1: setConnectedWallet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const { 0: connectVisible , 1: setConnectVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: disconnectVisible , 1: setDisconnectVisible  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (activeWallet) {
            const walletConnector = window.localStorage.getItem("walletConnector");
            // console.log(activeWallet);
            wallets.map((wallet)=>{
                const option = wallet.adapter;
                if (option.name === walletConnector) {
                    setConnectedWallet(option);
                }
            });
        }
    }, [
        wallets,
        activeWallet
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().header),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("wrap-fluid", (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().wrap)),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().logo),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/static/img/svg/logo.svg",
                            alt: "",
                            width: 157,
                            height: 28
                        })
                    })
                }),
                !activeWallet ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_tippyjs_react__WEBPACK_IMPORTED_MODULE_4___default()), {
                        content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_ConnectModal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            onConnected: ()=>{
                                setConnectVisible(false);
                                setDisconnectVisible(false);
                                closeModal();
                            }
                        }),
                        placement: "bottom",
                        offset: [
                            -94,
                            24
                        ],
                        arrow: false,
                        // trigger="click"
                        interactive: true,
                        allowHTML: true,
                        visible: connectVisible,
                        onClickOutside: ()=>{
                            setConnectVisible(false);
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().btnConnect),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                size: "sm",
                                onClick: ()=>{
                                    setConnectVisible(!connectVisible);
                                },
                                children: "Connect Wallet"
                            })
                        })
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_tippyjs_react__WEBPACK_IMPORTED_MODULE_4___default()), {
                        content: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_ProfileModal__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            onDisconnected: ()=>{
                                setConnectVisible(false);
                                setDisconnectVisible(false);
                                closeModal();
                            }
                        }),
                        placement: "bottom",
                        offset: [
                            -12,
                            12
                        ],
                        arrow: false,
                        // trigger="click"
                        interactive: true,
                        allowHTML: true,
                        visible: disconnectVisible,
                        onClickOutside: ()=>{
                            setDisconnectVisible(false);
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().btnConnect),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(components_common_Button__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                size: "sm",
                                secondary: true,
                                onClick: ()=>{
                                    setDisconnectVisible(!disconnectVisible);
                                },
                                children: [
                                    connectedWallet.hasOwnProperty("icon") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: connectedWallet.icon,
                                        alt: "",
                                        width: 16,
                                        height: 16
                                    }),
                                    (0,logic_helpers__WEBPACK_IMPORTED_MODULE_12__/* .walletSubstr */ .I4)(activeWallet)
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AppMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5795);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_4__);





function AppMenu() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const menu = [
        {
            href: "/app",
            label: "Staking",
            icon: "/static/img/svg/icons/menu-staking.svg"
        },
        {
            href: "/app/borrow",
            label: "Borrow",
            icon: "/static/img/svg/icons/menu-dashboard.svg"
        },
        {
            href: "/app/faucet",
            label: "Faucet",
            icon: "/static/img/svg/icons/menu-faucet.svg"
        }, 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().header),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: "/",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().logo),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/static/img/svg/logo.svg",
                        alt: "",
                        width: 157,
                        height: 28
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().menu),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    children: menu.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `${item.href}/`,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    className: router.route === item.href ? (_style_module_scss__WEBPACK_IMPORTED_MODULE_4___default().isActive) : undefined,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: item.icon,
                                            alt: item.label,
                                            width: 24,
                                            height: 24,
                                            loading: "lazy"
                                        }),
                                        item.label
                                    ]
                                })
                            })
                        }, item.href))
                })
            })
        ]
    });
};


/***/ }),

/***/ 5542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6398);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_2__);



function Footer() {
    const scrollToTop = ()=>{
        if (false) {}
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().footer),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().wrap), "wrap"),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().heading),
                    children: "Join Our Community"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().socials),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://twitter.com/wearedeltamoney",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/static/img/svg/icons/socials-twitter.svg",
                                    alt: "",
                                    width: 19,
                                    height: 15,
                                    loading: "lazy"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://t.me/deltamoneyofficial",
                                target: "_blank",
                                rel: "noreferrer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/static/img/svg/icons/socials-telegram.svg",
                                    alt: "",
                                    width: 22,
                                    height: 18,
                                    loading: "lazy"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().copyright),
                    children: "\xa9 2022 Delta Money, All rights reserved."
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_2___default().top),
                    onClick: scrollToTop,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/static/img/svg/icons/arrow-down--dm.svg"
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/common/Button/index.jsx
var Button = __webpack_require__(7755);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/Layout/Header/PrimaryMenu/style.module.scss
var style_module = __webpack_require__(8122);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./components/Layout/Header/PrimaryMenu/index.jsx





function PrimaryMenu({ opened  }) {
    const router = (0,router_.useRouter)();
    const menu = [
        {
            label: "Overview",
            anch: "#section-overview"
        },
        {
            label: "Why",
            anch: "#section-why"
        },
        {
            label: "Earn",
            anch: "#section-earn"
        },
        {
            label: "Ecosystem",
            anch: "#section-ecosystem"
        }, 
    ];
    const checkActiveClass = (route)=>{
        return router.route === route.slice(0, -1) ? (style_module_default()).active : "";
    };
    const onScrollTo = (anchor)=>{
        if (false) {}
    };
    const MenuLink = ({ item , noIcon =false  })=>{
        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: item.link,
            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                className: checkActiveClass(item.link),
                "data-disabled": item.disabled,
                children: item.label
            })
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: external_classnames_default()((style_module_default()).menu, "js__mobile-menu", {
            [(style_module_default()).opened]: opened
        }),
        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
            className: (style_module_default()).list,
            children: menu.map((item, idx)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                    onClick: ()=>onScrollTo(item.anch),
                    children: item.label
                }, idx))
        })
    });
}; // const IconCarret = () => (
 //   <svg
 //     width="9"
 //     height="6"
 //     viewBox="0 0 9 6"
 //     fill="#BCC2C9"
 //     xmlns="http://www.w3.org/2000/svg"
 //   >
 //     <path d="M0.472243 0.910841C0.716321 0.666764 1.11205 0.666764 1.35613 0.910841L4.49997 4.05469L7.64382 0.910841C7.88789 0.666764 8.28362 0.666764 8.5277 0.910841C8.77178 1.15492 8.77178 1.55065 8.5277 1.79472L4.94191 5.38051C4.69784 5.62459 4.30211 5.62459 4.05803 5.38051L0.472243 1.79472C0.228165 1.55065 0.228165 1.15492 0.472243 0.910841Z" />
 //   </svg>
 // );

// EXTERNAL MODULE: ./components/Layout/Header/style.module.scss
var Header_style_module = __webpack_require__(7006);
var Header_style_module_default = /*#__PURE__*/__webpack_require__.n(Header_style_module);
;// CONCATENATED MODULE: ./components/Layout/Header/index.jsx







function Header() {
    const { 0: openedMenu , 1: setOpenedMenu  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (typeof document !== "undefined") {
            document.addEventListener("click", (e)=>{
                if (!e.target.closest(".js__mobile-menu") && !e.target.closest(".js__menu-toggle") && openedMenu === true) {
                    setOpenedMenu(false);
                }
            }, {
                passive: true
            });
        }
    }, [
        openedMenu
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
            className: (Header_style_module_default()).header,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: external_classnames_default()((Header_style_module_default()).wrap, "wrap"),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: (Header_style_module_default()).logo,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/static/img/svg/logo.svg",
                                alt: "",
                                width: 157,
                                height: 28
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(PrimaryMenu, {
                        opened: openedMenu
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Header_style_module_default()).controls,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Header_style_module_default()).button,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        disabled: true,
                                        size: "sm",
                                        children: "Launch App"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Coming Soon"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: external_classnames_default()((Header_style_module_default()).toggleMenu, "js__menu-toggle", {
                                    [(Header_style_module_default()).isPressed]: openedMenu
                                }),
                                type: "button",
                                onClick: ()=>setOpenedMenu(!openedMenu),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {})
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 2075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _AppMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3138);
/* harmony import */ var _AppHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(204);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(648);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5542);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4623);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AppHeader__WEBPACK_IMPORTED_MODULE_2__]);
_AppHeader__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Layout({ children , app =false  }) {
    return app ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().parent),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AppMenu__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().main),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AppHeader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    children
                ]
            })
        ]
    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "yw": () => (/* reexport */ (message_default())),
  "t6": () => (/* reexport */ (notification_default()))
});

// UNUSED EXPORTS: Button, Checkbox, Col, Collapse, Drawer, Form, Input, InputNumber, Layout, List, Menu, Modal, PageHeader, Pagination, Popover, Row, Select, Skeleton, Slider, Spin, Switch, Table, Tabs, Tooltip

;// CONCATENATED MODULE: external "antd/lib/modal"
const modal_namespaceObject = require("antd/lib/modal");
;// CONCATENATED MODULE: external "antd/lib/skeleton"
const skeleton_namespaceObject = require("antd/lib/skeleton");
;// CONCATENATED MODULE: external "antd/lib/tooltip"
const tooltip_namespaceObject = require("antd/lib/tooltip");
;// CONCATENATED MODULE: external "antd/lib/layout"
const layout_namespaceObject = require("antd/lib/layout");
;// CONCATENATED MODULE: external "antd/lib/col"
const col_namespaceObject = require("antd/lib/col");
;// CONCATENATED MODULE: external "antd/lib/row"
const row_namespaceObject = require("antd/lib/row");
;// CONCATENATED MODULE: external "antd/lib/select"
const select_namespaceObject = require("antd/lib/select");
;// CONCATENATED MODULE: external "antd/lib/button"
const button_namespaceObject = require("antd/lib/button");
;// CONCATENATED MODULE: external "antd/lib/pagination"
const pagination_namespaceObject = require("antd/lib/pagination");
;// CONCATENATED MODULE: external "antd/lib/page-header"
const page_header_namespaceObject = require("antd/lib/page-header");
;// CONCATENATED MODULE: external "antd/lib/slider"
const slider_namespaceObject = require("antd/lib/slider");
;// CONCATENATED MODULE: external "antd/lib/collapse"
const collapse_namespaceObject = require("antd/lib/collapse");
;// CONCATENATED MODULE: external "antd/lib/table"
const table_namespaceObject = require("antd/lib/table");
;// CONCATENATED MODULE: external "antd/lib/popover"
const popover_namespaceObject = require("antd/lib/popover");
;// CONCATENATED MODULE: external "antd/lib/switch"
const switch_namespaceObject = require("antd/lib/switch");
;// CONCATENATED MODULE: external "antd/lib/input-number"
const input_number_namespaceObject = require("antd/lib/input-number");
;// CONCATENATED MODULE: external "antd/lib/list"
const list_namespaceObject = require("antd/lib/list");
;// CONCATENATED MODULE: external "antd/lib/checkbox"
const checkbox_namespaceObject = require("antd/lib/checkbox");
;// CONCATENATED MODULE: external "antd/lib/form"
const form_namespaceObject = require("antd/lib/form");
;// CONCATENATED MODULE: external "antd/lib/message"
const message_namespaceObject = require("antd/lib/message");
var message_default = /*#__PURE__*/__webpack_require__.n(message_namespaceObject);
;// CONCATENATED MODULE: external "antd/lib/notification"
const notification_namespaceObject = require("antd/lib/notification");
var notification_default = /*#__PURE__*/__webpack_require__.n(notification_namespaceObject);
;// CONCATENATED MODULE: external "antd/lib/drawer"
const drawer_namespaceObject = require("antd/lib/drawer");
;// CONCATENATED MODULE: external "antd/lib/tabs"
const tabs_namespaceObject = require("antd/lib/tabs");
;// CONCATENATED MODULE: external "antd/lib/menu"
const menu_namespaceObject = require("antd/lib/menu");
;// CONCATENATED MODULE: external "antd/lib/spin"
const spin_namespaceObject = require("antd/lib/spin");
;// CONCATENATED MODULE: external "antd/lib/input"
const input_namespaceObject = require("antd/lib/input");
;// CONCATENATED MODULE: ./components/common/Antd/index.jsx




























/***/ }),

/***/ 6613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ConnectModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Title__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(527);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7755);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5384);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_5__);






const Option = ({ onClick , label , icon  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
            type: "button",
            onClick: onClick ? onClick : undefined,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: icon,
                    alt: "",
                    width: 52,
                    height: 52
                }),
                label
            ]
        })
    });
};
function ConnectModal({ onConnected , onlyButton =false  }) {
    const { wallets , select  } = (0,_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_2__.useWallet)();
    const onConnectWallet = async ()=>{
        // console.log("CONNECT");
        await select("Martian");
    };
    const renderButtonGroup = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return wallets.map((wallet)=>{
            const option = wallet.adapter;
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                label: option.name,
                icon: option.icon,
                onClick: async ()=>{
                    window.localStorage.setItem("walletConnector", option.name);
                    await select(option.name);
                    onConnected();
                }
            }, option.name);
        });
    }, [
        wallets,
        select,
        onConnected
    ]);
    return onlyButton ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        size: "sm",
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().btnConnect),
        onClick: ()=>onConnectWallet(),
        children: "Connect Wallet"
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().modal),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Title__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    size: "h6",
                    block: true,
                    tac: true,
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: "Connect your wallet"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_5___default().list),
                    children: renderButtonGroup
                })
            ]
        })
    });
};


/***/ }),

/***/ 3413:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProfileModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var aptos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7574);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_common_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7755);
/* harmony import */ var hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1381);
/* harmony import */ var logic_helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2582);
/* harmony import */ var lib_web3helper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(563);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5786);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([aptos__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__]);
([aptos__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const NODE_URL = "https://fullnode.devnet.aptoslabs.com";
function ProfileModal({ onDisconnected  }) {
    const aptosClient = new aptos__WEBPACK_IMPORTED_MODULE_2__.AptosClient(NODE_URL);
    // const coinClient = new CoinClient(aptosClient);
    const { disconnect  } = (0,_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_3__.useWallet)();
    const { activeWallet  } = (0,hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { 0: currentWalletBalanceAptos , 1: setCurrentWalletBalanceAptos  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const getUserBalance = async ()=>{
            try {
                // const account = new AptosAccount();
                // const balance = await coinClient.checkBalance(account);
                const walletResources = await aptosClient.getAccountResources(activeWallet.toString());
                const walletResource = walletResources.find((r)=>r.type === "0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>");
                setCurrentWalletBalanceAptos(lib_web3helper__WEBPACK_IMPORTED_MODULE_6__/* ["default"].fromWei */ .Z.fromWei(walletResource.data.coin.value));
            } catch (e) {}
        };
        if (activeWallet) {
            getUserBalance().then().catch(console.error);
        }
    }, [
        activeWallet
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_7___default().modal),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_7___default().subtitle),
                children: "BALANCE:"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_7___default().text),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        width: 18,
                        height: 18,
                        src: `/static/img/svg/coins/aptos.svg`
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: {
                            width: "100%"
                        },
                        children: [
                            (0,logic_helpers__WEBPACK_IMPORTED_MODULE_8__/* .numberFormat */ .Y4)(currentWalletBalanceAptos, 2, ".", ",", true),
                            " APT"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                red: true,
                size: "xs",
                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_7___default().btnConnect),
                onClick: async ()=>{
                    await disconnect();
                    onDisconnected();
                },
                children: "Disconnect"
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7475:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ aptosClient)
/* harmony export */ });
/* unused harmony export faucetClient */
/* harmony import */ var aptos__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7574);
/* harmony import */ var _aptosConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2968);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([aptos__WEBPACK_IMPORTED_MODULE_0__]);
aptos__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const faucetClient = new aptos__WEBPACK_IMPORTED_MODULE_0__.FaucetClient(_aptosConstants__WEBPACK_IMPORTED_MODULE_1__/* .NODE_URL */ .xs, _aptosConstants__WEBPACK_IMPORTED_MODULE_1__/* .FAUCET_URL */ .ti);
const aptosClient = new aptos__WEBPACK_IMPORTED_MODULE_0__.AptosClient(_aptosConstants__WEBPACK_IMPORTED_MODULE_1__/* .NODE_URL */ .xs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ti": () => (/* binding */ FAUCET_URL),
/* harmony export */   "xs": () => (/* binding */ NODE_URL)
/* harmony export */ });
/* unused harmony exports KEY_LENGTH, ENCRYPTED_WALLET_LIST, CONNECT_PASSWORD, WALLET_STATE_NETWORK_LOCAL_STORAGE_KEY, LOCAL_NODE_URL, DEVNET_NODE_URL, LOCAL_FAUCET_URL, DEVNET_FAUCET_URL, WEBWALLET_URL */
const KEY_LENGTH = 64;
const ENCRYPTED_WALLET_LIST = "encryptedAptosWalletList";
const CONNECT_PASSWORD = "aptosWalletPassword";
const WALLET_STATE_NETWORK_LOCAL_STORAGE_KEY = "aptosWalletNetworkState";
const LOCAL_NODE_URL = "http://127.0.0.1:8080";
const DEVNET_NODE_URL = "https://fullnode.devnet.aptoslabs.com/v1";
const LOCAL_FAUCET_URL = "http://127.0.0.1:8000";
const DEVNET_FAUCET_URL = "https://faucet.devnet.aptoslabs.com";
const WEBWALLET_URL = "https://hippo-wallet-test.web.app";
// export const WEBWALLET_URL = 'http://localhost:3030';
const NODE_URL = DEVNET_NODE_URL;
const FAUCET_URL = DEVNET_FAUCET_URL;


/***/ }),

/***/ 1569:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GX": () => (/* binding */ coinListClient),
/* harmony export */   "Kn": () => (/* binding */ hippoSwapClient),
/* harmony export */   "nx": () => (/* binding */ hippoWalletClient),
/* harmony export */   "sW": () => (/* binding */ hippoTradeAggregator)
/* harmony export */ });
/* harmony import */ var _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6306);
/* harmony import */ var utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6522);
/* harmony import */ var _aptosClient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7475);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__, utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__, _aptosClient__WEBPACK_IMPORTED_MODULE_2__]);
([_manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__, utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__, _aptosClient__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const errorHandler = (0,lodash__WEBPACK_IMPORTED_MODULE_3__.debounce)(// eslint-disable-next-line @typescript-eslint/no-unused-vars
(_err)=>{
    // store.dispatch(commonActions.SET_RESOURCES_NOT_FOUND(true));
    antd__WEBPACK_IMPORTED_MODULE_4__.message.error("Resource not found or loaded");
}, 1000, {
    leading: false,
    trailing: true
});
const hippoWalletClient = async (account)=>{
    let walletClient;
    try {
        if (!account) return undefined;
        const netConf = (0,utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__/* .readConfig */ .z)();
        walletClient = await _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.HippoWalletClient.createInTwoCalls(netConf, new _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.App(_aptosClient__WEBPACK_IMPORTED_MODULE_2__/* .aptosClient */ .M), account, netConf.simulationKeys);
    } catch (err) {
        console.log("Get hippo wallet client failed", err);
    // errorHandler(err);
    }
    return walletClient;
};
const hippoSwapClient = async ()=>{
    let swapClient;
    try {
        const netConf = (0,utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__/* .readConfig */ .z)();
        swapClient = await _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.HippoSwapClient.createInOneCall(new _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.App(_aptosClient__WEBPACK_IMPORTED_MODULE_2__/* .aptosClient */ .M), netConf, netConf.simulationKeys);
    } catch (err) {
        console.log("Get hippo swap client failed", err);
    // errorHandler(err);
    }
    return swapClient;
};
const hippoTradeAggregator = async ()=>{
    let agg;
    try {
        agg = await _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.TradeAggregator.create(_aptosClient__WEBPACK_IMPORTED_MODULE_2__/* .aptosClient */ .M);
    } catch (err) {
        console.log("Get hippo trade aggregator failed", err);
    // errorHandler(err);
    }
    return agg;
};
const coinListClient = async ()=>{
    let client;
    try {
        const netConf = (0,utils_hippoWalletUtil__WEBPACK_IMPORTED_MODULE_1__/* .readConfig */ .z)();
        client = await _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.CoinListClient.load(new _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.App(_aptosClient__WEBPACK_IMPORTED_MODULE_2__/* .aptosClient */ .M), netConf.simulationKeys);
    } catch (err) {
        console.log("Get coin list client failed", err);
    // errorHandler(err);
    }
    return client;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2430:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ HippoClientProvider)
/* harmony export */ });
/* unused harmony export HippoClientContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var config_hippoClients__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1569);
/* harmony import */ var hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1381);
/* harmony import */ var components_common_Antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6718);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var modules_swap_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(440);
/* harmony import */ var hooks_useNotification__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3356);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([config_hippoClients__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_3__]);
([config_hippoClients__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const HippoClientContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const HippoClientProvider = ({ children  })=>{
    const { activeWallet  } = (0,hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { signAndSubmitTransaction  } = (0,_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_5__.useWallet)();
    const { openNotification  } = (0,hooks_useNotification__WEBPACK_IMPORTED_MODULE_8__/* .useNotification */ .l)();
    const { 0: hippoWallet , 1: setHippoWallet  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: hippoSwap , 1: setHippoSwapClient  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: hippoAgg , 1: setHippoAgg  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: refresh , 1: setRefresh  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: transaction , 1: setTransaction  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: tokenStores , 1: setTokenStores  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: tokenInfos , 1: setTokenInfos  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const getHippoWalletClient = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        if (activeWallet) {
            const client = await (0,config_hippoClients__WEBPACK_IMPORTED_MODULE_2__/* .hippoWalletClient */ .nx)(activeWallet);
            await (client === null || client === void 0 ? void 0 : client.refreshStores());
            setHippoWallet(client);
        } else {
            setHippoWallet(undefined);
        }
    }, [
        activeWallet
    ]);
    const getHippoSwapClient = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        const sClient = await (0,config_hippoClients__WEBPACK_IMPORTED_MODULE_2__/* .hippoSwapClient */ .Kn)();
        setHippoSwapClient(sClient);
    }, []);
    const getHippoTradeAggregator = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        setHippoAgg(await (0,config_hippoClients__WEBPACK_IMPORTED_MODULE_2__/* .hippoTradeAggregator */ .sW)());
    }, []);
    const getTokenInfos = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        const client = await (0,config_hippoClients__WEBPACK_IMPORTED_MODULE_2__/* .coinListClient */ .GX)();
        /*
    console.log(
      'coin list',
      client?.coinList.map((c) => c.name.str())
    );
    */ setTokenInfos(client === null || client === void 0 ? void 0 : client.symbolToCoinInfo);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getHippoWalletClient();
        getHippoSwapClient();
        getHippoTradeAggregator();
        getTokenInfos();
    }, [
        getHippoWalletClient,
        getHippoSwapClient,
        getHippoTradeAggregator,
        getTokenInfos, 
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (hippoWallet) {
            setTokenStores(hippoWallet === null || hippoWallet === void 0 ? void 0 : hippoWallet.symbolToCoinStore);
            if (refresh) {
                getHippoWalletClient();
                setRefresh(false);
            }
        } else {
            setTokenStores(undefined);
        }
    }, [
        hippoWallet,
        refresh,
        getHippoWalletClient
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (hippoSwap) {
            dispatch(modules_swap_actions__WEBPACK_IMPORTED_MODULE_7__/* ["default"].SET_TOKEN_LIST */ .Z.SET_TOKEN_LIST(hippoSwap.singleCoins));
        }
    }, [
        dispatch,
        hippoSwap
    ]);
    const getNotificationMsg = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((txhash)=>{
        const description = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            children: [
                "You can verify the transaction by visiting the",
                " ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `https://explorer.devnet.aptos.dev/txn/${txhash}`,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "underline",
                    children: "Aptos Transaction Explorer"
                })
            ]
        });
        return openNotification(description);
    }, [
        openNotification
    ]);
    const requestFaucet = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (symbol)=>{
        let success = false;
        try {
            if (!activeWallet) throw new Error("Please login first");
            const uiAmtUsed = symbol === "BTC" ? 0.01 : 10;
            const payload = hippoWallet === null || hippoWallet === void 0 ? void 0 : hippoWallet.makeFaucetMintToPayload(uiAmtUsed, symbol, true);
            if (payload && tokenInfos) {
                let pl = payload;
                const result = await signAndSubmitTransaction(pl);
                if (result) {
                    components_common_Antd__WEBPACK_IMPORTED_MODULE_4__/* .message.success */ .yw.success("Faucet Success");
                    getNotificationMsg(result.hash);
                    await (hippoWallet === null || hippoWallet === void 0 ? void 0 : hippoWallet.refreshStores());
                    setRefresh(true);
                    success = true;
                }
            }
        } catch (error) {
            console.log("request faucet error:", error);
            if (error instanceof Error) {
                components_common_Antd__WEBPACK_IMPORTED_MODULE_4__/* .message.error */ .yw.error(error === null || error === void 0 ? void 0 : error.message);
            }
            success = false;
        } finally{
            return success;
        }
    }, [
        activeWallet,
        getNotificationMsg,
        hippoWallet,
        signAndSubmitTransaction,
        tokenInfos, 
    ]);
    const requestSwapByRoute = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async (routeAndQuote, slipTolerance)=>{
        let success = false;
        try {
            const input = routeAndQuote.quote.inputUiAmt;
            const minOut = routeAndQuote.quote.outputUiAmt * (1 - slipTolerance / 100);
            if (!activeWallet) throw new Error("Please connect wallet first");
            if (input <= 0) {
                throw new Error("Input amount needs to be greater than 0");
            }
            const payload = routeAndQuote.route.makePayload(input, minOut, true);
            const result = await signAndSubmitTransaction(payload);
            if (result) {
                components_common_Antd__WEBPACK_IMPORTED_MODULE_4__/* .message.success */ .yw.success("Transaction Success");
                getNotificationMsg(result.hash);
                setRefresh(true);
                success = true;
            }
        } catch (error) {
            console.log("request swap by route error:", error);
            if (error instanceof Error) {
                components_common_Antd__WEBPACK_IMPORTED_MODULE_4__/* .message.error */ .yw.error(error === null || error === void 0 ? void 0 : error.message);
            }
            success = false;
        } finally{
            return success;
        }
    }, [
        activeWallet,
        getNotificationMsg,
        signAndSubmitTransaction
    ]);
    /*
  const requestDeposit = useCallback(
    async (
      lhsSymbol: string,
      rhsSymbol: string,
      poolType: PoolType,
      lhsUiAmt: number,
      rhsUiAmt: number
    ) => {
      let success = false;
      try {
        if (!activeWallet || !hippoSwap) {
          throw new Error('Please login first');
        }
        const pool = hippoSwap.getDirectPoolsBySymbolsAndPoolType(lhsSymbol, rhsSymbol, poolType);
        if (pool.length === 0) {
          throw new Error('Desired pool does not exist');
        }
        const payload = await pool[0].makeAddLiquidityPayload(lhsUiAmt, rhsUiAmt);
        const result = await signAndSubmitTransaction(payload);
        if (result) {
          message.success('Transaction Success');
          getNotificationMsg(result.hash);
          setRefresh(true);
          success = true;
        }
      } catch (error) {
        console.log('request deposit error:', error);
        if (error instanceof Error) {
          message.error(error?.message);
        }
        success = false;
      } finally {
        return success;
      }
    },
    [hippoSwap, activeWallet, signAndSubmitTransaction]
  );

  const requestWithdraw = useCallback(
    async (
      lhsSymbol: string,
      rhsSymbol: string,
      poolType: PoolType,
      liqiudityAmt: UITokenAmount,
      lhsMinAmt: UITokenAmount,
      rhsMinAmt: UITokenAmount
    ) => {
      let success = false;
      try {
        if (!activeWallet || !hippoSwap) {
          throw new Error('Please login first');
        }
        const pool = hippoSwap.getDirectPoolsBySymbolsAndPoolType(lhsSymbol, rhsSymbol, poolType);
        if (pool.length === 0) {
          throw new Error('Desired pool does not exist');
        }
        const payload = await pool[0].makeRemoveLiquidityPayload(
          liqiudityAmt,
          lhsMinAmt,
          rhsMinAmt
        );
        const result = await signAndSubmitTransaction(payload);
        if (result) {
          message.success('Transaction Success');
          getNotificationMsg(result.hash);
          setRefresh(true);
          success = true;
        }
      } catch (error) {
        console.log('request withdraw error:', error);
        if (error instanceof Error) {
          message.error(error?.message);
        }
        success = false;
      } finally {
        return success;
      }
    },
    [hippoSwap, activeWallet, signAndSubmitTransaction]
  );
  */ return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HippoClientContext.Provider, {
        value: {
            hippoWallet,
            hippoSwap,
            hippoAgg,
            tokenStores,
            tokenInfos,
            requestSwapByRoute,
            transaction,
            setTransaction,
            requestFaucet
        },
        children: children
    });
};


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ useNotification)
/* harmony export */ });
/* harmony import */ var components_common_Antd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6718);

const useNotification = ()=>{
    const openNotification = (description)=>{
        components_common_Antd__WEBPACK_IMPORTED_MODULE_0__/* .notification.open */ .t6.open({
            message: "Transaction Success",
            description,
            placement: "bottomLeft"
        });
    };
    return {
        openNotification
    };
};


/***/ }),

/***/ 563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const BigNumber = __webpack_require__(4215);
BigNumber.set({
    ROUNDING_MODE: BigNumber.ROUND_DOWN
});
BigNumber.config({
    EXPONENTIAL_AT: [
        -1e9,
        1e9
    ]
});
const web3helper = {
    toBN (number) {
        return new BigNumber(number);
    },
    toWei (number, decimals = 8) {
        return this.toBN(number).multipliedBy("1e" + decimals).toString();
    },
    fromWei (number, decimals = 8) {
        return this.toBN(number).dividedBy("1e" + decimals);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (web3helper);


/***/ }),

/***/ 8573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modules_rootReducer)
});

// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: ./modules/account/actions.jsx

const SET_SELECTED_ACCOUNT = (0,toolkit_.createAction)("account/SET_SELECTED_ACCOUNT");
/* harmony default export */ const actions = ({
    SET_SELECTED_ACCOUNT
});

;// CONCATENATED MODULE: ./modules/account/reducer.jsx


const initState = {
    selectedAccount: null
};
/* harmony default export */ const reducer = ((0,toolkit_.createReducer)(initState, (builder)=>{
    builder.addCase(actions.SET_SELECTED_ACCOUNT, (state, action)=>{
        state.selectedAccount = action.payload;
    });
}));
const getSelectedAccount = (state)=>state.account.selectedAccount;

;// CONCATENATED MODULE: ./modules/account/index.jsx


/* harmony default export */ const account = ({
    actions: actions,
    reducer: reducer
});

;// CONCATENATED MODULE: ./modules/common/actions.jsx

const SET_LAYOUT_HEIGHT = (0,toolkit_.createAction)("pool/SET_LAYOUT_HEIGHT");
const TOGGLE_WALLET_CONNECTOR = (0,toolkit_.createAction)("common/TOGGLE_WALLET_CONNECTOR");
const SET_RESOURCES_NOT_FOUND = (0,toolkit_.createAction)("common/SET_RESOURCES_NOT_FOUND");
/* harmony default export */ const common_actions = ({
    SET_LAYOUT_HEIGHT,
    TOGGLE_WALLET_CONNECTOR,
    SET_RESOURCES_NOT_FOUND
});

;// CONCATENATED MODULE: ./modules/common/reducer.jsx



const reducer_initState = {
    layoutHeight: 0,
    showWalletConnector: false,
    isResourcesNotFound: false
};
/* harmony default export */ const common_reducer = ((0,toolkit_.createReducer)(reducer_initState, (builder)=>{
    builder.addCase(common_actions.SET_LAYOUT_HEIGHT, (state, { payload  })=>{
        state.layoutHeight = payload;
    }).addCase(common_actions.TOGGLE_WALLET_CONNECTOR, (state, { payload  })=>{
        state.showWalletConnector = payload === undefined ? !state.showWalletConnector : payload;
    }).addCase(common_actions.SET_RESOURCES_NOT_FOUND, (state, { payload  })=>{
        state.isResourcesNotFound = payload;
    });
}));
const getLayoutHeight = (state)=>state.common.layoutHeight;
const getShowWalletConnector = (state)=>state.common.showWalletConnector;
const getIsResourcesNotFound = (state)=>state.common.isResourcesNotFound;

;// CONCATENATED MODULE: ./modules/common/index.jsx


/* harmony default export */ const common = ({
    actions: common_actions,
    reducer: common_reducer
});

;// CONCATENATED MODULE: ./modules/pool/actions.jsx

const SET_IS_FETCHING = (0,toolkit_.createAction)("pool/SET_IS_FETCHING");
const SET_POOL_LIST = (0,toolkit_.createAction)("pool/SET_POOL_LIST");
const SET_FILTERS = (0,toolkit_.createAction)("pool/SET_FILTERS");
/* harmony default export */ const pool_actions = ({
    SET_IS_FETCHING,
    SET_POOL_LIST,
    SET_FILTERS
});

;// CONCATENATED MODULE: external "lodash/sortBy"
const sortBy_namespaceObject = require("lodash/sortBy");
var sortBy_default = /*#__PURE__*/__webpack_require__.n(sortBy_namespaceObject);
;// CONCATENATED MODULE: ./modules/pool/reducer.jsx



const pool_reducer_initState = {
    isFetching: false,
    isFetched: false,
    error: null,
    poolList: [],
    filters: {
        search: "",
        filterBy: "",
        sortBy: "",
        showSelfLiquidity: false
    }
};
/* harmony default export */ const pool_reducer = ((0,toolkit_.createReducer)(pool_reducer_initState, (builder)=>{
    builder.addCase(pool_actions.SET_IS_FETCHING, (state, { payload  })=>{
        state.isFetching = payload;
        state.isFetched = false;
    }).addCase(pool_actions.SET_POOL_LIST, (state, { payload  })=>{
        state.poolList = payload;
        state.isFetching = false;
        state.isFetched = true;
    }).addCase(pool_actions.SET_FILTERS, (state, { payload  })=>{
        state.filters = payload;
    });
}));
const getIsFetchingPoolList = (state)=>state.pool.isFetching;
const getIsFetchedPoolList = (state)=>state.pool.isFetched;
const getPoolList = (state)=>state.pool.poolList;
const getPoolFilters = (state)=>state.pool.filters;
const getPoolSummary = (0,toolkit_.createSelector)(getPoolList, (poolList)=>{
    const totalValueLocked = poolList.reduce((totalValue, pool)=>{
        return totalValue + parseFloat(pool.totalValueLockedUSD);
    }, 0);
    const total24Vol = poolList.reduce((totalValue, pool)=>{
        return totalValue + parseFloat(pool.volumeUSD);
    }, 0);
    return {
        totalValueLocked,
        total24Vol
    };
});
const getFilteredPoolList = (0,toolkit_.createSelector)(getPoolFilters, getPoolList, (filters, poolList)=>{
    let filteredList = poolList;
    if (filters.sortBy) filteredList = sortBy_default()(filteredList, filters.sortBy);
    if (!filters.search) return filteredList;
    filteredList = filteredList.filter((pool)=>{
        const keysToFilter = [
            pool.token0.symbol,
            pool.token1.symbol,
            pool.token0.name,
            pool.token1.name, 
        ].join(",").toLowerCase();
        return keysToFilter.includes(filters.search);
    });
    return filteredList;
});

;// CONCATENATED MODULE: ./modules/pool/index.jsx


/* harmony default export */ const pool = ({
    actions: pool_actions,
    reducer: pool_reducer
});

// EXTERNAL MODULE: ./modules/swap/actions.jsx
var swap_actions = __webpack_require__(440);
;// CONCATENATED MODULE: ./modules/swap/reducer.jsx


const swap_reducer_initState = {
    isFetching: false,
    isFetched: false,
    error: null,
    tokenList: [],
    swapSettings: {
        slipTolerance: 1,
        trasactionDeadline: 30,
        maxGasFee: 1000,
        currencyFrom: {
            token: undefined,
            amount: undefined,
            balance: 0
        },
        currencyTo: {
            token: undefined,
            amount: undefined,
            balance: 0
        }
    }
};
/* harmony default export */ const swap_reducer = ((0,toolkit_.createReducer)(swap_reducer_initState, (builder)=>{
    builder.addCase(swap_actions/* default.SET_IS_FETCHING */.Z.SET_IS_FETCHING, (state, { payload  })=>{
        state.isFetching = payload;
        state.isFetched = false;
    }).addCase(swap_actions/* default.SET_TOKEN_LIST */.Z.SET_TOKEN_LIST, (state, { payload  })=>{
        state.tokenList = payload;
        state.isFetching = false;
        state.isFetched = true;
    }).addCase(swap_actions/* default.SET_SWAP_SETTING */.Z.SET_SWAP_SETTING, (state, { payload  })=>{
        state.swapSettings = payload;
    }).addCase(swap_actions/* default.RESET */.Z.RESET, (state)=>{
        state.swapSettings = swap_reducer_initState.swapSettings;
    });
}));
const getIsFetchingTokenList = (state)=>state.swap.isFetching;
const getIsFetchedTokenList = (state)=>state.swap.isFetched;
const getTokenList = (state)=>state.swap.tokenList;
const getSwapSettings = (state)=>state.swap.swapSettings;

;// CONCATENATED MODULE: ./modules/swap/index.jsx


/* harmony default export */ const swap = ({
    actions: swap_actions/* default */.Z,
    reducer: swap_reducer
});

;// CONCATENATED MODULE: ./modules/rootReducer.jsx





const rootReducer = (0,toolkit_.combineReducers)({
    account: account.reducer,
    swap: swap.reducer,
    pool: pool.reducer,
    common: common.reducer
});
/* harmony default export */ const modules_rootReducer = (rootReducer);


/***/ }),

/***/ 440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const SET_IS_FETCHING = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("swap/SET_IS_FETCHING");
const SET_TOKEN_LIST = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("swap/SET_TOKEN_LIST");
const SET_SWAP_SETTING = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("swap/SET_SWAP_SETTING");
const RESET = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAction)("swap/RESET");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    SET_IS_FETCHING,
    SET_TOKEN_LIST,
    SET_SWAP_SETTING,
    RESET
});


/***/ }),

/***/ 2581:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2075);
/* harmony import */ var wrappers_Providers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3637);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_Layout__WEBPACK_IMPORTED_MODULE_1__, wrappers_Providers__WEBPACK_IMPORTED_MODULE_2__]);
([components_Layout__WEBPACK_IMPORTED_MODULE_1__, wrappers_Providers__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(wrappers_Providers__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            app: pageProps.app || false,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6522:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ readConfig)
/* harmony export */ });
/* harmony import */ var _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6306);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__]);
_manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const readConfig = ()=>{
    const isDevnet = true;
    const netConf = isDevnet ? _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.CONFIGS.devnet : _manahippo_hippo_sdk__WEBPACK_IMPORTED_MODULE_0__.CONFIGS.localhost;
    return netConf;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3637:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export store */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var modules_rootReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8573);
/* harmony import */ var contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1579);
/* harmony import */ var contexts_HippoClientProvider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2430);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4736);
/* harmony import */ var _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_4__, contexts_HippoClientProvider__WEBPACK_IMPORTED_MODULE_5__]);
([contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_4__, contexts_HippoClientProvider__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const isDevelopmentMode = "production" === "development";
const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.configureStore)({
    reducer: modules_rootReducer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
    devTools: isDevelopmentMode,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: false,
            immutableCheck: {
                ignoredPaths: [
                    "connection"
                ]
            }
        }).concat([])
});
const Providers = (props)=>{
    const wallets = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>[
            // new HippoWalletAdapter(),
            //new HippoExtensionWalletAdapter(),
            new _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.MartianWalletAdapter(),
            new _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.FewchaWalletAdapter(),
            new _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.AptosWalletAdapter(),
            // new MultiMaskWalletAdapter(),
            // new NightlyWalletAdapter(),
            new _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.PontemWalletAdapter(),
            new _manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.SpikaWalletAdapter(), 
        ], []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_manahippo_aptos_wallet_adapter__WEBPACK_IMPORTED_MODULE_6__.WalletProvider, {
        wallets: wallets,
        autoConnect: true,
        onError: (error)=>{
            console.log("wallet errors: ", error);
            let text = "";
            if (error.name === "WalletNotReadyError") {
                text = "Wallet not ready";
            }
            antd__WEBPACK_IMPORTED_MODULE_8__.message.error(error.message || text);
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(contexts_AptosWalletProvider__WEBPACK_IMPORTED_MODULE_4__/* .AptosWalletProvider */ .Z, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_1__.Provider, {
                store: store,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(contexts_HippoClientProvider__WEBPACK_IMPORTED_MODULE_5__/* .HippoClientProvider */ .p, {
                    children: props.children
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Providers);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4736:
/***/ ((module) => {

"use strict";
module.exports = require("@manahippo/aptos-wallet-adapter");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4787:
/***/ ((module) => {

"use strict";
module.exports = require("@tippyjs/react");

/***/ }),

/***/ 5725:
/***/ ((module) => {

"use strict";
module.exports = require("antd");

/***/ }),

/***/ 4215:
/***/ ((module) => {

"use strict";
module.exports = require("bignumber.js");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6306:
/***/ ((module) => {

"use strict";
module.exports = import("@manahippo/hippo-sdk");;

/***/ }),

/***/ 7574:
/***/ ((module) => {

"use strict";
module.exports = import("aptos");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,755,582,527,381], () => (__webpack_exec__(2581)));
module.exports = __webpack_exports__;

})();