(() => {
var exports = {};
exports.id = 366;
exports.ids = [366];
exports.modules = {

/***/ 4858:
/***/ ((module) => {

// Exports
module.exports = {
	"card": "style_card__fHJNo",
	"isFinished": "style_isFinished__F52Jf",
	"type": "style_type__RpNdw",
	"typeModal": "style_typeModal__NtZZy",
	"title": "style_title__E48NE",
	"subtitleLine": "style_subtitleLine__9aWf0",
	"token": "style_token___PtwE",
	"info": "style_info__VZyHd",
	"infoBlock": "style_infoBlock__WY4OI",
	"withIcons": "style_withIcons__TOr6p",
	"huge": "style_huge__BYICI",
	"infoBlockLogo": "style_infoBlockLogo__thbPT",
	"infoBlockTitle": "style_infoBlockTitle__HWqd4",
	"infoBlockSubtitle": "style_infoBlockSubtitle__vgCf_",
	"infoBlockValue": "style_infoBlockValue__lKJMv",
	"infoBlockGrid": "style_infoBlockGrid__ph8qG",
	"infoBLockSubtitle": "style_infoBLockSubtitle__7Eazf",
	"infoBlockData": "style_infoBlockData__xVWgZ",
	"body": "style_body__V6YYU",
	"btn": "style_btn__CEZLd",
	"balance": "style_balance__4GqVt",
	"balanceLabel": "style_balanceLabel__7DNuU",
	"balanceBtn": "style_balanceBtn__dWux0",
	"form": "style_form__U7nml",
	"grid": "style_grid__yE9Le",
	"line": "style_line__KsfIK",
	"block": "style_block__sijwD",
	"blockTitle": "style_blockTitle___PT_C",
	"blockValue": "style_blockValue__Jn_3I",
	"foot": "style_foot__5jwf_",
	"total": "style_total__8Ts4A",
	"progress": "style_progress__5Osdz",
	"progressHead": "style_progressHead__hXRuK",
	"progressItem": "style_progressItem__NkoPy",
	"progressItemSubtitle": "style_progressItemSubtitle__mTVI2",
	"progressItemText": "style_progressItemText__z5G8y",
	"progressBar": "style_progressBar__6LTKz",
	"modalHead": "style_modalHead__p2rEB",
	"modalItem": "style_modalItem__jh5GG",
	"modalItemSubtitle": "style_modalItemSubtitle__9WD1n",
	"modalItemText": "style_modalItemText__mKIxw",
	"modalTabs": "style_modalTabs__JSCAG",
	"isSelected": "style_isSelected__1R8Nj",
	"modalFoot": "style_modalFoot__7p1mY",
	"btnSubmit": "style_btnSubmit__bpTcw",
	"btnMax": "style_btnMax__u4Irl",
	"field": "style_field__Y4ba9",
	"skeleton": "style_skeleton__nDYex"
};


/***/ }),

/***/ 597:
/***/ ((module) => {

// Exports
module.exports = {
	"btn": "style_btn__q2kDM"
};


/***/ }),

/***/ 8766:
/***/ ((module) => {

// Exports
module.exports = {
	"head": "staking_head__iow10",
	"highlights": "staking_highlights__DYaws",
	"subtitle": "staking_subtitle__5mV_V",
	"highlightsList": "staking_highlightsList__mcYFA",
	"highlightsListToken": "staking_highlightsListToken__Zq0_L",
	"highlightsListApy": "staking_highlightsListApy__KhbAo",
	"tvl": "staking_tvl__TtG_f",
	"tvlNum": "staking_tvlNum__7AA_Q",
	"grid": "staking_grid__ff486",
	"progress": "staking_progress__S_sIZ",
	"progressHead": "staking_progressHead__wZgRF",
	"progressFoot": "staking_progressFoot__tLkLG",
	"progressBar": "staking_progressBar__vpufT"
};


/***/ }),

/***/ 6428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ VaultCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
;// CONCATENATED MODULE: external "react-loading-skeleton"
const external_react_loading_skeleton_namespaceObject = require("react-loading-skeleton");
var external_react_loading_skeleton_default = /*#__PURE__*/__webpack_require__.n(external_react_loading_skeleton_namespaceObject);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
// EXTERNAL MODULE: ./components/common/Modal/index.jsx
var Modal = __webpack_require__(1079);
// EXTERNAL MODULE: ./components/common/Button/index.jsx
var Button = __webpack_require__(7755);
// EXTERNAL MODULE: external "@tippyjs/react"
var react_ = __webpack_require__(4787);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./components/common/InfoTooltip/style.module.scss
var style_module = __webpack_require__(597);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: ./node_modules/tippy.js/dist/tippy.css
var tippy = __webpack_require__(8933);
;// CONCATENATED MODULE: ./components/common/InfoTooltip/index.jsx





function InfoTooltip({ content , className , trigger ="click"  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx((react_default()), {
        content: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: content
        }),
        trigger: trigger,
        interactive: true,
        allowHTML: true,
        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            type: "button",
            className: external_classnames_default()((style_module_default()).btn, className),
            children: /*#__PURE__*/ jsx_runtime_.jsx(IconInfo, {})
        })
    });
};
const IconInfo = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "12",
        height: "12",
        viewBox: "0 0 12 12",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                cx: "6",
                cy: "6",
                r: "5",
                fill: "#22264B"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "#919BB9",
                d: "M5.76333 4.2605C5.89904 4.39918 6.08317 4.47719 6.27526 4.47739V4.4774C6.46735 4.47805 6.65177 4.40059 6.78777 4.2622C6.92377 4.12381 7.00014 3.93587 7 3.73992C7.00028 3.54396 6.92426 3.35593 6.78864 3.21714C6.65303 3.0784 6.4689 3.0003 6.27686 3C6.08477 2.99975 5.90044 3.07736 5.76444 3.2157C5.62844 3.35409 5.55193 3.54192 5.55174 3.73788C5.55154 3.93383 5.62766 4.12182 5.76333 4.2605ZM5.39709 9H5.78001L5.78 8.99996C6.11412 8.82291 6.41177 8.58831 6.70236 8.34949C6.7751 8.28762 6.84332 8.22041 6.90649 8.14844C6.93541 8.11409 6.95976 8.07593 6.97883 8.03505C7.00382 7.99099 6.99887 7.93571 6.96651 7.897C6.937 7.85785 6.88601 7.8428 6.8406 7.85983C6.7647 7.88923 6.6865 7.91982 6.61119 7.95342C6.59036 7.96204 6.56971 7.97134 6.54907 7.98063C6.50794 7.99914 6.46682 8.01765 6.42414 8.03084C6.40081 8.04405 6.37199 8.04173 6.35098 8.025C6.32992 8.00826 6.32075 7.9803 6.32764 7.95402C6.34016 7.83707 6.35976 7.72104 6.38649 7.60661C6.55626 6.90413 6.7253 6.20167 6.89352 5.49919C6.97649 5.15658 6.80003 4.87811 6.45942 4.80793C6.36825 4.78882 6.27359 4.79887 6.18824 4.83673C6.12288 4.86109 6.06049 4.89311 6.00236 4.93211V4.93216C5.72997 5.13317 5.46292 5.33422 5.20057 5.54482C5.1265 5.61625 5.05929 5.6948 5 5.77944V5.92164C5.04575 5.985 5.13163 6.00173 5.19708 5.96005H5.19704C5.24867 5.93991 5.29927 5.91644 5.34993 5.89295C5.38529 5.87654 5.42069 5.86013 5.45647 5.84482C5.49408 5.82666 5.53352 5.8128 5.57413 5.80345C5.59878 5.79335 5.62697 5.7984 5.64677 5.81646C5.66661 5.83453 5.67471 5.86249 5.66763 5.88863C5.65706 5.99197 5.63959 6.09443 5.61528 6.1953V6.19525C5.55645 6.43829 5.4973 6.68127 5.43815 6.92424C5.31985 7.41015 5.20155 7.89607 5.08588 8.3825C5.02121 8.64714 5.13765 8.87399 5.38001 8.98678C5.38618 8.9905 5.3919 8.9949 5.39709 9Z"
            })
        ]
    });

// EXTERNAL MODULE: ./lib/walletProvider.js
var walletProvider = __webpack_require__(6237);
// EXTERNAL MODULE: ./logic/helpers/index.js
var helpers = __webpack_require__(2582);
// EXTERNAL MODULE: ./components/cards/VaultCard/style.module.scss
var VaultCard_style_module = __webpack_require__(4858);
var VaultCard_style_module_default = /*#__PURE__*/__webpack_require__.n(VaultCard_style_module);
;// CONCATENATED MODULE: ./components/cards/VaultCard/index.jsx












function VaultCard({ data , key , aptosClient , balanceUserAptos , walletAddress ,  }) {
    const { strategyTitle , title , description , tokenPrimary , tokenSecondary , tokenPrimarySymbol , tokenSecondarySymbol , apy , tvl , providedBy , maxCap , value , staking_addr , staking_module ,  } = data;
    const { 0: visibleModal , 1: setVisibleModal  } = (0,external_react_.useState)(false);
    const { 0: modalTab , 1: setModalTab  } = (0,external_react_.useState)(0);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { 0: stakingAPY , 1: setStakingAPY  } = (0,external_react_.useState)(0);
    const { 0: stakingMaxCapacity , 1: setStakingMaxCapacity  } = (0,external_react_.useState)(0);
    const { 0: stakingCurrentDeposit , 1: setStakingCurrentDeposit  } = (0,external_react_.useState)(0);
    const { 0: stakingAvailableWithdraw , 1: setStakingAvailableWithdraw  } = (0,external_react_.useState)(0);
    const { 0: stakingAvailableRewards , 1: setStakingAvailableRewards  } = (0,external_react_.useState)(0);
    const { 0: stakingWalletWhenStake , 1: setStakingWalletWhenStake  } = (0,external_react_.useState)(0);
    const { 0: stakingWalletRewardsAmount , 1: setStakingWalletRewardsAmount  } = (0,external_react_.useState)(0);
    const { 0: stakingAvailableOwnAmount , 1: setStakingAvailableOwnAmount  } = (0,external_react_.useState)(0);
    const { 0: percentVal , 1: setPercentVal  } = (0,external_react_.useState)(0);
    const { 0: currentWalletBalanceAptos , 1: setCurrentWalletBalanceAptos  } = (0,external_react_.useState)(0);
    const { 0: checkInfoStakingAndWallet , 1: setCheckInfoStakingAndWallet  } = (0,external_react_.useState)(0);
    (0,external_react_.useEffect)(()=>{
        getContractInfo().then().catch(console.error);
    }, [
        staking_addr
    ]);
    (0,external_react_.useEffect)(()=>{
        if (walletAddress) {
            getUserInfo().then().catch(console.error);
        }
    }, [
        walletAddress
    ]);
    (0,external_react_.useEffect)(()=>{
        if (stakingMaxCapacity) {
            // console.log('stakingMaxCapacity')
            // console.log(stakingMaxCapacity)
            try {
                setPercentVal(Math.ceil(stakingCurrentDeposit * 100 / stakingMaxCapacity));
            } catch (e) {}
        }
    }, [
        stakingMaxCapacity
    ]);
    (0,external_react_.useEffect)(()=>{
        setCurrentWalletBalanceAptos(balanceUserAptos);
    }, [
        balanceUserAptos
    ]);
    (0,external_react_.useEffect)(()=>{
        const id = setInterval(()=>{
            getContractInfo().then().catch(console.error);
            getUserInfo().then().catch(console.error);
            setCheckInfoStakingAndWallet(checkInfoStakingAndWallet + 1);
        }, 10000);
        return ()=>clearInterval(id);
    }, [
        checkInfoStakingAndWallet
    ]);
    const getContractInfo = async ()=>{
        try {
            // console.log(staking_module)
            switch(staking_module){
                case "StakingWood":
                    const contractResources = await aptosClient.getAccountResources("0x" + staking_addr);
                    // console.log(contractResources)
                    const contractResource = contractResources.find((r)=>r.type === `0x${staking_addr}::${staking_module}::StakingInfo`);
                    console.log("contractInfo", contractResource === null || contractResource === void 0 ? void 0 : contractResource.data);
                    setStakingAPY(parseInt(contractResource.data.apy));
                    setStakingMaxCapacity(parseInt(contractResource.data.max_allowed_stake));
                    setStakingCurrentDeposit(parseInt(contractResource.data.total_staked_amount));
                    break;
            }
        } catch (e) {
            console.log(e);
        }
    };
    const getUserInfo = async ()=>{
        try {
            // console.log(staking_module)
            switch(staking_module){
                case "StakingWood":
                    if (walletAddress) {
                        // console.log(walletAddress)
                        const walletResources = await aptosClient.getAccountResources(walletAddress);
                        const walletResource = walletResources.find((r)=>r.type === `0x${staking_addr}::${staking_module}::UserStakeInfo`);
                        const walletWhenStake = parseInt(walletResource.data.when_stake);
                        const walletStakeAmount = parseInt(walletResource.data.staked_amount);
                        const walletRewordsAmount = parseInt(walletResource.data.rewards_amount);
                        const walletRewordsPerSecond = calcRewordsAmount(walletStakeAmount, stakingAPY, walletWhenStake);
                        console.log("rounded reward per second: ", walletRewordsPerSecond);
                        // setStakingWhenUserStake(parseInt(walletResource.data.when_stake))
                        setStakingWalletWhenStake(walletWhenStake);
                        setStakingWalletRewardsAmount(walletRewordsAmount);
                        setStakingAvailableOwnAmount(walletStakeAmount);
                        setStakingAvailableRewards(walletRewordsAmount + walletRewordsPerSecond);
                        setStakingAvailableWithdraw(walletStakeAmount + walletRewordsAmount + walletRewordsPerSecond);
                        const walletResourceBalance = walletResources.find((r)=>r.type === "0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>");
                        setCurrentWalletBalanceAptos(parseInt(walletResourceBalance.data.coin.value));
                        // console.log(stakingAvailableRewards)
                        console.log("walletInfo", walletResource.data);
                        setLoading(false);
                    }
                    break;
            }
        } catch (e) {
            console.log(e);
        }
    };
    const calcRewordsAmount = (staked_amount, apy, when_stake)=>{
        const percentage_amount = 10000000000; // for correct calc rewords by second
        // Calculate percents amount after year. Example: 100T, 20% = 120T to withdraw after year. And 20T - percent amount
        const percent_rewords_amount = staked_amount * percentage_amount * apy / 101;
        // Calculate amount to withdraw per second from percent.
        // Example: 120T - 100T = 20T percent reward. 20T / <second in year> = <x>T percent reward by second
        const percent_rewords_amount_in_second = percent_rewords_amount / (12 * 30 * 24 * 60 * 60);
        // Seconds passed from vesting when_stake_time to now()
        const second_passed = Math.floor(Date.now() / 1000) - when_stake;
        // Calculate token amount to withdraw for base balance and for percent
        const rewors_per_stake_period = second_passed * percent_rewords_amount_in_second;
        console.log("NOT rounded reward per second:", rewors_per_stake_period / percentage_amount);
        return parseInt(rewors_per_stake_period / percentage_amount);
    };
    const onOpenModal = (item)=>{
        setVisibleModal(true);
    };
    const onCloseModal = ()=>{
        setModalTab(0);
        setVisibleModal(false);
    };
    const onDeposit = async (values)=>{
        if (parseInt(values.value) > 0) {
            try {
                switch(staking_module){
                    case "StakingWood":
                        console.log(values);
                        await walletProvider/* default.sendTransaction */.Z.sendTransaction({
                            transactionData: {
                                type: "entry_function_payload",
                                function: `0x${staking_addr}::StakingWood::stake`,
                                arguments: [
                                    parseInt(values.value)
                                ],
                                type_arguments: []
                            }
                        });
                        await getContractInfo();
                        await getUserInfo();
                        break;
                }
            } catch (e) {
                console.log(e);
            }
        }
    };
    const onWithdraw = async (values)=>{
        if (parseInt(values.value) > 0) {
            try {
                switch(staking_module){
                    case "StakingWood":
                        console.log(values);
                        await walletProvider/* default.sendTransaction */.Z.sendTransaction({
                            transactionData: {
                                type: "entry_function_payload",
                                function: `0x${staking_addr}::StakingWood::unstake`,
                                arguments: [
                                    parseInt(values.value)
                                ],
                                type_arguments: []
                            }
                        });
                        await getContractInfo();
                        await getUserInfo();
                        break;
                }
            } catch (e) {
                console.log(e);
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: external_classnames_default()((VaultCard_style_module_default()).card),
                onClick: ()=>onOpenModal({
                        data: data
                    }),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (VaultCard_style_module_default()).type,
                        children: strategyTitle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(InfoBlock, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (VaultCard_style_module_default()).subtitleLine,
                        children: description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (VaultCard_style_module_default()).body,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ProgressBlock, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FooterBlock, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                isVisible: visibleModal,
                onClose: ()=>onCloseModal(),
                withHead: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: external_classnames_default()((VaultCard_style_module_default()).type, (VaultCard_style_module_default()).typeModal),
                            children: strategyTitle
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(InfoBlock, {
                            type: "huge"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (VaultCard_style_module_default()).modalHead,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (VaultCard_style_module_default()).modalItem,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (VaultCard_style_module_default()).modalItemSubtitle,
                                        children: [
                                            tokenPrimarySymbol,
                                            " balance:"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: (VaultCard_style_module_default()).modalItemText,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                width: 24,
                                                height: 24,
                                                src: tokenPrimary
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                style: {
                                                    width: "100%"
                                                },
                                                children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: (VaultCard_style_module_default()).skeleton,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {})
                                                }) : `${(0,helpers/* numberFormat */.Y4)(currentWalletBalanceAptos)} ${tokenPrimarySymbol}`
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (VaultCard_style_module_default()).modalTabs,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                type: "button",
                                                className: modalTab === 0 ? (VaultCard_style_module_default()).isSelected : undefined,
                                                onClick: ()=>setModalTab(0),
                                                children: "Deposit"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                type: "button",
                                                className: modalTab === 1 ? (VaultCard_style_module_default()).isSelected : undefined,
                                                onClick: ()=>setModalTab(1),
                                                children: "Withdraw"
                                            })
                                        })
                                    ]
                                }),
                                modalTab === 0 && /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: external_yup_.object().shape({
                                        value: external_yup_.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onDeposit(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Form, {
                                            autoComplete: "off",
                                            className: (VaultCard_style_module_default()).form,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (VaultCard_style_module_default()).field,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: (VaultCard_style_module_default()).btnMax,
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", balanceUserAptos);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        type: "submit",
                                                        className: (VaultCard_style_module_default()).btnSubmit,
                                                        children: "Deposit"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                }),
                                modalTab === 1 && /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
                                    initialValues: {
                                        value: 0
                                    },
                                    validationSchema: external_yup_.object().shape({
                                        value: external_yup_.number().required("Error")
                                    }),
                                    onSubmit: (values)=>onWithdraw(values),
                                    children: (props)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Form, {
                                            autoComplete: "off",
                                            className: external_classnames_default()((VaultCard_style_module_default()).form),
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: (VaultCard_style_module_default()).field,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "number",
                                                        name: "value",
                                                        placeholder: "0",
                                                        onChange: (e)=>{
                                                            props.setFieldValue("value", e.target.value);
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        type: "button",
                                                        className: (VaultCard_style_module_default()).btnMax,
                                                        onClick: ()=>{
                                                            props.setFieldValue("value", 100);
                                                        },
                                                        children: "Max"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                                        type: "submit",
                                                        className: (VaultCard_style_module_default()).btnSubmit,
                                                        red: true,
                                                        children: "Withdraw"
                                                    })
                                                ]
                                            })
                                        });
                                    }
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (VaultCard_style_module_default()).modalFoot,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (VaultCard_style_module_default()).total,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Own stake amount:"
                                        }),
                                        loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (VaultCard_style_module_default()).skeleton,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {})
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    (0,helpers/* numberFormat */.Y4)(stakingAvailableOwnAmount, 0, ".", ","),
                                                    " ",
                                                    tokenSecondarySymbol
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (VaultCard_style_module_default()).total,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Rewards:"
                                        }),
                                        loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (VaultCard_style_module_default()).skeleton,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {})
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    " ",
                                                    (0,helpers/* numberFormat */.Y4)(stakingAvailableRewards, 0, ".", ","),
                                                    " ",
                                                    tokenSecondarySymbol
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (VaultCard_style_module_default()).total,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Total available withdraw:"
                                        }),
                                        loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (VaultCard_style_module_default()).skeleton,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_loading_skeleton_default()), {})
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                children: [
                                                    (0,helpers/* numberFormat */.Y4)(stakingAvailableWithdraw, 0, ".", ","),
                                                    " ",
                                                    tokenSecondarySymbol
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (VaultCard_style_module_default()).total,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                            children: "Available stake:"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    children: [
                                                        (0,helpers/* numberFormat */.Y4)(stakingMaxCapacity - stakingCurrentDeposit, 0, ".", ","),
                                                        " ",
                                                        tokenSecondarySymbol
                                                    ]
                                                }),
                                                " "
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
    function InfoBlock({ type ="normal"  }) {
        const wh = type === "huge" ? 40 : 32;
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (VaultCard_style_module_default()).info,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: external_classnames_default()((VaultCard_style_module_default()).infoBlock, (VaultCard_style_module_default()).withIcons, {
                        [(VaultCard_style_module_default()).huge]: type === "huge"
                    }),
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (VaultCard_style_module_default()).infoBlockLogo,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                width: wh,
                                height: wh,
                                src: tokenPrimary
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (VaultCard_style_module_default()).infoBlockTitle,
                            children: title
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (VaultCard_style_module_default()).infoBlock,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (VaultCard_style_module_default()).infoBlockSubtitle,
                            children: [
                                "APY ",
                                /*#__PURE__*/ jsx_runtime_.jsx(InfoTooltip, {
                                    content: "APY per year",
                                    trigger: "mouseenter"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (VaultCard_style_module_default()).infoBlockValue,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: stakingAPY
                                }),
                                " %"
                            ]
                        })
                    ]
                })
            ]
        });
    }
    function ProgressBlock() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (VaultCard_style_module_default()).progress,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (VaultCard_style_module_default()).progressHead,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (VaultCard_style_module_default()).progressItem
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (VaultCard_style_module_default()).progressItem,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (VaultCard_style_module_default()).progressItemSubtitle,
                                    children: "Provided by"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (VaultCard_style_module_default()).progressItemText,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            width: 16,
                                            height: 16,
                                            src: `/static/img/pages/staking/providers/${providedBy.toLowerCase()}.png`
                                        }),
                                        providedBy
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (VaultCard_style_module_default()).progressBar,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        style: {
                            width: percentVal + "%"
                        }
                    })
                })
            ]
        });
    }
    function DepositBlock() {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    }
    function FooterBlock() {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (VaultCard_style_module_default()).foot,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (VaultCard_style_module_default()).total,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "Current Deposit (APT):"
                        }),
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                (0,helpers/* numberFormat */.Y4)(stakingCurrentDeposit ?? 0, 2, ".", ","),
                                " APT"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (VaultCard_style_module_default()).total,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                            children: "Max Capacity (APT):"
                        }),
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                (0,helpers/* numberFormat */.Y4)(stakingMaxCapacity ?? 0, 2, ".", ","),
                                " APT"
                            ]
                        })
                    ]
                })
            ]
        });
    }
};


/***/ }),

/***/ 4894:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ PageStaking),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var aptos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7574);
/* harmony import */ var components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4390);
/* harmony import */ var components_cards_VaultCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6428);
/* harmony import */ var hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1381);
/* harmony import */ var logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9688);
/* harmony import */ var styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8766);
/* harmony import */ var styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([aptos__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__]);
([aptos__WEBPACK_IMPORTED_MODULE_2__, hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function PageStaking({ vaults  }) {
    const { activeWallet  } = (0,hooks_useAptosWallet__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { 0: walletAddress , 1: setWalletAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: balanceUserAptos , 1: setBalanceUserAptos  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    // devnet is used here for testing
    const NODE_URL = "https://fullnode.devnet.aptoslabs.com";
    const FAUCET_URL = "https://faucet.devnet.aptoslabs.com";
    const aptosClient = new aptos__WEBPACK_IMPORTED_MODULE_2__.AptosClient(NODE_URL);
    const faucetClient = new aptos__WEBPACK_IMPORTED_MODULE_2__.FaucetClient(NODE_URL, FAUCET_URL);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // const autoConnect = async () => {
        //   if (walletAddress) {
        //     setWalletAddress(walletAddress);
        //   } else {
        //     const isConnected = await walletProvider.isConnected();
        //     // console.log(isConnected);
        //     if (isConnected) {
        //       const account = await walletProvider.getAccount();
        //       setWalletAddress(account);
        //     }
        //   }
        // };
        // autoConnect().catch((error) => console.log(error));
        if (activeWallet) {
            setWalletAddress(activeWallet.toString());
        }
    }, [
        activeWallet
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (walletAddress) {
            const getUserBalance = async ()=>{
                try {
                    const walletResources = await aptosClient.getAccountResources(walletAddress);
                    // console.log(contrResource)
                    const walletResource = walletResources.find((r)=>r.type === "0x1::coin::CoinStore<0x1::aptos_coin::AptosCoin>");
                    // console.log(walletResource.data.coin);
                    setBalanceUserAptos(walletResource.data.coin.value);
                // setBalanceUserAptos((contrAccountResource?.data as any).coin.value)
                } catch (e) {}
            };
            getUserBalance().then().catch(console.error);
        }
    }, [
        walletAddress
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_common_SeoMeta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                type: "app"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "wrap-fluid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7___default().head),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7___default().highlights)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (styles_pages_staking_module_scss__WEBPACK_IMPORTED_MODULE_7___default().grid),
                        children: vaults.map((item, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_cards_VaultCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                data: item,
                                aptosClient: aptosClient,
                                balanceUserAptos: balanceUserAptos,
                                walletAddress: walletAddress
                            }, idx))
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps(ctx) {
    const { req , res  } = ctx;
    if (ctx.req) {
        await (0,logic_httpAuthCheck__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(req, res);
    }
    const vaults = [
        {
            strategyTitle: "Stable Strategy APTOS",
            title: "APTOS",
            description: "Earn fees with minimal directional exposure. DeltaMoney manages trading ranges, rebalancing and auto-compounding of all rewards.",
            tokenPrimary: "/static/img/svg/coins/aptos.svg",
            // tokenSecondary: '/static/img/svg/coins/usdc.svg',
            tokenPrimarySymbol: "APT",
            // tokenSecondarySymbol: 'USDC',
            apy: 100,
            tvl: 29.97,
            providedBy: "Harvik",
            maxCap: 500000,
            value: 463008,
            staking_addr: "f9140dce450238d26cf82e15b75bfc59f77d7fc70ddc1cb9d4d510ef9bba85e9",
            staking_module: "StakingWood"
        }, 
    ];
    return {
        props: {
            app: true,
            vaults: vaults
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8933:
/***/ (() => {



/***/ }),

/***/ 4736:
/***/ ((module) => {

"use strict";
module.exports = require("@manahippo/aptos-wallet-adapter");

/***/ }),

/***/ 4787:
/***/ ((module) => {

"use strict";
module.exports = require("@tippyjs/react");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 3290:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-basic-auth");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 7574:
/***/ ((module) => {

"use strict";
module.exports = import("aptos");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,390,755,582,968,381], () => (__webpack_exec__(4894)));
module.exports = __webpack_exports__;

})();