import { createAction } from "@reduxjs/toolkit";

const SET_SELECTED_ACCOUNT = createAction("account/SET_SELECTED_ACCOUNT");

export default {
  SET_SELECTED_ACCOUNT,
};
